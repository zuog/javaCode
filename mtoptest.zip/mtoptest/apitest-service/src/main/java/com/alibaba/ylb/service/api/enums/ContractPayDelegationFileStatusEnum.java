/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.api.enums;

/**
 * 类ContractPayDelegationFileStatusEnum.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午2:35:50
 */
public enum ContractPayDelegationFileStatusEnum implements ValuedEnum {
    /**
     * 无需提交需提交（表示合同主体和付款主体相同）
     */
    UNNEED_SUBMIT(0, "无需提交需提交（表示合同主体和付款主体相同）"),

    /**
     * 待提交
     */
    UNSUBMIT(1, "待提交"),

    /**
     * 待审核
     */
    UNCHECKED(2, "待审核"),

    /**
     * 通过
     */
    APPROVED(3, "通过"),

    /**
     * 通过
     */
    REFUSED(4, "通过");

    private int    value;

    private String desc;

    private ContractPayDelegationFileStatusEnum(int value, String desc){
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return value;
    }

    public static ContractPayDelegationFileStatusEnum valueOf(int value) {
        return valueOf(value, null);
    }

    public static ContractPayDelegationFileStatusEnum valueOf(int value, ContractPayDelegationFileStatusEnum defaultValue) {
        for (ContractPayDelegationFileStatusEnum type : ContractPayDelegationFileStatusEnum.values()) {
            if (type.getValue() == value) {
                return type;
            }
        }
        return defaultValue;
    }
}
