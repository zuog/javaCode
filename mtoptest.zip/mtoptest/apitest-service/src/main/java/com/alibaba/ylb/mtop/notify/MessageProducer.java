package com.alibaba.ylb.mtop.notify;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.taobao.notify.message.StringMessage;
import com.taobao.notify.remotingclient.NotifyManagerBean;
import com.taobao.notify.remotingclient.SendResult;

/**
 * Notify的消息生产者示例。通过@Autowired注入Notify的消息生产者NotifyManagerBean，并通过它发送消息。详情见
 * http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-notify
 *
 * @author chengxu
 */
@Component("notify")
public class MessageProducer {

    @Autowired
    @Qualifier("publisherNotifyManager")
    NotifyManagerBean publisherNotifyManager;

    @Value("${spring.notify.subscriber.binding.topic}")
    String topic;
    @Value("${spring.notify.subscriber.binding.key}")
    String messageType;

    public boolean sendMessage(String messageBody) {
        StringMessage message = new StringMessage();
        /*
         * 必选字段:topic, tag, body
         */
        message.setTopic(topic);
        message.setBody(messageBody);
        message.setMessageType(messageType);

        /*
         * 发送成功则没有异常抛出，失败则抛异常
         */
        try {
            SendResult sendResult = publisherNotifyManager.sendMessage(message);
            return sendResult.isSuccess();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
