package com.alibaba.ylb.mtop.uic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.taobao.uic.common.domain.BaseUserDO;
import com.taobao.uic.common.domain.ResultDO;
import com.taobao.uic.common.service.userdata.client.UicDataReadServiceClient;
import com.taobao.uic.common.service.userinfo.client.UicReadServiceClient;

/**
 * 使用UIC提供的API进行用户信息查询。详见 http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-uic
 * 
 * @author chengxu
 */
@Component
public class UicQueryDemo {

    private final static String DOMAIN_KEY = "tagcenter-sellersrv-userdata";

    @Autowired
    private UicReadServiceClient uicReadServiceClient;

    @Autowired
    private UicDataReadServiceClient uicDataReadServiceClient;

    /**
     * 根据user id查询用户的相关信息
     * 
     * @param userId 用户的id
     * @return 用户信息
     */
    public UserInfo queryUserByUserId(long userId) {
        UserInfo result = new UserInfo();
        ResultDO<BaseUserDO> userQueryResult = uicReadServiceClient.getBaseUserByUserId(userId);
        if (userQueryResult.isSuccess()) {
            BaseUserDO baseUserDo = userQueryResult.getModule();
            result.setMobilePhone(baseUserDo.getMobilePhone());
            result.setLoginId(baseUserDo.getLoginId());
            result.setNick(baseUserDo.getNick());
        } else {
            throw new RuntimeException("Can not find user by user id  " + userId);
        }

        ResultDO<String> dataQueryResult = uicDataReadServiceClient.getData(userId, DOMAIN_KEY);
        if (dataQueryResult.isSuccess()) {
            result.setData(dataQueryResult.getModule());
        } else {
            throw new RuntimeException("Can not find user data by user id  " + userId);
        }

        return result;
    }

    /**
     * 根据用户昵称查询user id
     * 
     * @param nick 用户昵称
     * @return 用户的id
     */
    public long queryUserIdByNick(String nick) {
        ResultDO<Long> queryResult = uicReadServiceClient.getUserIdByNick(nick);
        if (queryResult.isSuccess()) {
            return queryResult.getModule();
        } else {
            throw new RuntimeException("Can not find user by nick " + nick);
        }
    }

    class UserInfo {

        private String mobilePhone;
        private String loginId;
        private String nick;
        private String data;

        public String getMobilePhone() {
            return mobilePhone;
        }

        public void setMobilePhone(String mobilePhone) {
            this.mobilePhone = mobilePhone;
        }

        public String getLoginId() {
            return loginId;
        }

        public void setLoginId(String loginId) {
            this.loginId = loginId;
        }

        public String getNick() {
            return nick;
        }

        public void setNick(String nick) {
            this.nick = nick;
        }

        public String getData() {
            return data;
        }

        public void setData(String data) {
            this.data = data;
        }
    }
}
