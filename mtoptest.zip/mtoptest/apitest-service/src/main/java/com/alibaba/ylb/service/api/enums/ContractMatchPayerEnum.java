/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.api.enums;

/**
 * 类ContractMatchPayerEnum.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午2:35:10
 */
public enum ContractMatchPayerEnum implements ValuedEnum {

    /**
     * 合同主体和付款主体不相同
     */
    MATCH(0, "合同主体和付款主体不相同"),

    /**
     * 合同主体和付款主体相同
     */
    UNMATCH(1, "合同主体和付款主体相同"),

    /**
     * 商家还未进行选择
     */
    UNKNOWN(2, "商家还未进行选择"), ;

    private int    value;

    private String desc;

    private ContractMatchPayerEnum(int value, String desc){
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return value;
    }

    public static ContractMatchPayerEnum valueOf(int value) {
        return valueOf(value, null);
    }

    public static ContractMatchPayerEnum valueOf(int value, ContractMatchPayerEnum defaultValue) {
        for (ContractMatchPayerEnum type : ContractMatchPayerEnum.values()) {
            if (type.getValue() == value) {
                return type;
            }
        }
        return defaultValue;
    }
}
