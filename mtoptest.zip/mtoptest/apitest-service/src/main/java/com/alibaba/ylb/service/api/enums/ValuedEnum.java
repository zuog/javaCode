/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.api.enums;

/**
 * 类ValuedEnum.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午2:11:48
 */
public interface ValuedEnum {

    /**
     * @return
     */
    int getValue();

}
