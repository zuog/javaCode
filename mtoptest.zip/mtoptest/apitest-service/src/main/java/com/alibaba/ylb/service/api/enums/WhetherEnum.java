/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.api.enums;

/**
 * 类WhetherEnum.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月13日 下午7:51:41
 */
public enum WhetherEnum implements ValuedEnum {
    /**
     * 否
     */
    NO(0, "否"),

    /**
     * 是
     */
    YES(1, "是");

    private int    value;
    private String desc;

    /**
     * @param value
     * @param desc
     */
    
    private WhetherEnum(int value, String desc){
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return value;
    }

    public String getDesc() {
        return desc;
    }
}