package com.alibaba.ylb.mtop.schedulerx;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.alibaba.dts.client.executor.job.processor.SimpleJobProcessor;
import com.alibaba.dts.client.executor.simple.processor.SimpleJobContext;
import com.alibaba.dts.common.domain.result.ProcessResult;

/**
 * schedulerx的定时任务，任务定时信息等需要在schedulerx控制台配置。详见
 * http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-schedulerx
 * 
 * @author chengxu
 */
public class JobDemo implements SimpleJobProcessor {

    private SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

    /**
     * 定时执行的任务方法
     * 
     * @param context 定时任务调用的上下文，包括任务参数、定时表达式、任务创建时间等
     * @return 任务执行的结果，是否成功，重试次数等
     */
    @Override
    public ProcessResult process(SimpleJobContext context) {
        String arguments = context.getJob().getJobArguments();
        String cronExpress = context.getJob().getCronExpression();
        Date jobCreateTime = context.getJobInstanceSnapshot().getGmtCreate();

        System.out
                .println(formatter.format(jobCreateTime) + "   arguments:" + arguments + ",cronExpress:" + cronExpress);
        return new ProcessResult(true);
    }

}
