/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.mtop.tddl.mybatis;

import com.alibabapictures.sqbservice.module.MerchantDO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 类MerchantMapper.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月13日 下午7:04:33
 */
@Mapper
public interface MerchantMapper {

    /**
     * 商家基本信息存储
     * 
     * @param merchantDO 商家基本信息
     * @return
     */
    int save(MerchantDO merchantDO);

    /**
     * 根据商家id查询商家基本信息
     * 
     * @param id 商家id
     * @return
     */
    MerchantDO getById(long id);

}
