/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.api.enums;

/**
 * 类ContractPayStatusEnum.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午2:30:48
 */
public enum ContractPayStatusEnum implements ValuedEnum {
    /**
     * 未付款
     */
    UNPAID(0, "未付款"),

    /**
     * 已付款
     */
    PAID(1, "已付款");

    private int    value;
    private String desc;

    private ContractPayStatusEnum(int value, String desc){
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return value;
    }

    public static ContractPayStatusEnum valueOf(int value) {
        return valueOf(value, null);
    }

    public static ContractPayStatusEnum valueOf(int value, ContractPayStatusEnum defaultValue) {
        for (ContractPayStatusEnum type : ContractPayStatusEnum.values()) {
            if (type.getValue() == value) {
                return type;
            }
        }
        return defaultValue;
    }

}
