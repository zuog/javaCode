/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.api.enums;

/**
 * 类ContractCommissionTypeEnum.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午2:33:22
 */
public enum ContractCommissionTypeEnum implements ValuedEnum {
    /**
     * 普通分佣
     */
    ORDINARY_COMMISSION(0, "普通分佣"),

    /**
     * 阶梯分佣
     */
    LADDER_COMMISSION(1, "阶梯分佣");

    private int    value;

    private String desc;

    private ContractCommissionTypeEnum(int value, String desc){
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return value;
    }

    public static ContractCommissionTypeEnum valueOf(int value) {
        return valueOf(value, null);
    }

    public static ContractCommissionTypeEnum valueOf(int value, ContractCommissionTypeEnum defaultValue) {
        for (ContractCommissionTypeEnum type : ContractCommissionTypeEnum.values()) {
            if (type.getValue() == value) {
                return type;
            }
        }
        return defaultValue;
    }

}
