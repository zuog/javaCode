/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.mtop.tddl.mybatis;

import java.util.List;

import com.alibabapictures.sqbservice.module.ContractDO;
import org.apache.ibatis.annotations.Mapper;

/**
 * 类ContractMapper.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午1:49:56
 */
@Mapper
public interface ContractMapper {

    /**
     * 根据合同id查询合同详情
     * 
     * @param id
     * @return
     */
    ContractDO selectByContractId(Long id);

    /**
     * @param contractDO
     */
    void insertContract(ContractDO contractDO);

    /**
     * @param contractDO
     */
    void updateContract(ContractDO contractDO);

    /**
     * @return
     */
    List<String> listDistinctCreator();

}
