package com.alibaba.ylb.mtop.notify;

import org.springframework.stereotype.Service;

import com.taobao.notify.message.BytesMessage;
import com.taobao.notify.message.Message;
import com.taobao.notify.message.StringMessage;
import com.taobao.notify.remotingclient.MessageListener;
import com.taobao.notify.remotingclient.MessageStatus;
import com.taobao.notify.utils.UniqId;

/**
 * Notify消息消费者的示例，messageListener在application.properties中配置。详情见
 * http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-notify
 *
 * @author chengxu
 */
@Service(value = "messageListener")
public class MessageListenerImpl implements MessageListener {

    private volatile Message lastReceivedMessage;

    public Message getLastReceivedMessage() {
        return lastReceivedMessage;
    }

    /**
     * 处理消息
     */
    private boolean dealWithMessage(Message message) {
        try {
            lastReceivedMessage = message;
            String messageId = UniqId.getInstance().bytes2string(message.getMessageId());
            String topic = message.getTopic();
            String messageType = message.getMessageType();

            System.out.println("MessageId: " + messageId);
            System.out.println("Topic: " + topic);
            System.out.println("MessageType: " + messageType);
            if (message instanceof StringMessage) {
                System.out.println("String body: " + ((StringMessage) message).getBody());
            } else if (message instanceof BytesMessage) {
                BytesMessage bytesMessage = (BytesMessage) message;
                System.out.println("Byte body: " + new String(bytesMessage.getBody()));
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    @Override
    public void receiveMessage(Message message, MessageStatus status) {
        if (!dealWithMessage(message)) {
            // 消费失败，回滚继续重投
            status.setRollbackOnly();
            status.setReason("failture reason");
        }
    }
}
