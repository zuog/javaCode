/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.api.enums;

/**
 * 类ContractStatusEnum.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午1:58:33
 */
public enum ContractStatusEnum implements ValuedEnum {

    /**
     * 未签约
     */
    UNSIGNED(0, "未签约"),

    SIGNED(1, "已签约")
    ;

    private int    value;
    private String desc;

    private ContractStatusEnum(int value, String desc){
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return value;
    }

    public static ContractStatusEnum valueOf(int value) {
        return valueOf(value, null);
    }

    public static ContractStatusEnum valueOf(int value, ContractStatusEnum defaultValue) {
        for (ContractStatusEnum type : ContractStatusEnum.values()) {
            if (type.getValue() == value) {
                return type;
            }
        }
        return defaultValue;
    }

}
