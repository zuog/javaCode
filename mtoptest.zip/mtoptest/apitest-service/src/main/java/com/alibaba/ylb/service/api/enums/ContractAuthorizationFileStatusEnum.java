/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.api.enums;

/**
 * 类ContractAuthorizationFileStatusEnum.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午2:34:18
 */
public enum ContractAuthorizationFileStatusEnum implements ValuedEnum {

    /**
     * 未寄送
     */
    UNSEND(0, "未寄送"),

    /**
     * 已寄送
     */
    SEND(1, "已签收")

    ;

    private int    value;

    private String desc;

    private ContractAuthorizationFileStatusEnum(int value, String desc){
        this.value = value;
        this.desc = desc;
    }

    @Override
    public int getValue() {
        return value;
    }

    public static ContractAuthorizationFileStatusEnum valueOf(int value) {
        return valueOf(value, null);
    }

    public static ContractAuthorizationFileStatusEnum valueOf(int value, ContractAuthorizationFileStatusEnum defaultValue) {
        for (ContractAuthorizationFileStatusEnum type : ContractAuthorizationFileStatusEnum.values()) {
            if (type.getValue() == value) {
                return type;
            }
        }
        return defaultValue;
    }

}
