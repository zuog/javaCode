package com.alibaba.ylb.mtop.acl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.boot.acl.builder.CheckPermissionsParamBuilder;
import com.alibaba.boot.acl.config.AclProperties;
import com.alibaba.buc.acl.api.input.check.CheckPermissionsParam;
import com.alibaba.buc.acl.api.output.check.CheckPermissionsResult;
import com.alibaba.buc.acl.api.service.AccessControlService;

/**
 * 使用ACL的示例，详情见 http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-acl
 *
 * @author chengxu
 */
@Component
public class AclDemo {

    @Autowired
    private AclProperties properties;

    @Autowired
    AccessControlService accessControlService;

    public String checkPermission() {
        CheckPermissionsParam checkPermissionsParam = buildPermissionsParam();

        CheckPermissionsResult result = accessControlService.checkPermissions(checkPermissionsParam);
        if (!result.isSuccess()) {
            return null;
        }

        return translateResultToJson(result);
    }

    private CheckPermissionsParam buildPermissionsParam() {
        return CheckPermissionsParamBuilder
                .create()
                .accessKey(properties.getAccessKey())
                .permission("hello_acl_query_user")
                .permission("hello_acl_not_exist")
                .permission("hello_acl_not_grant_to_anyone")
                .permissions("a", "b", "c").userId(111154856)
                .operatorUserId(111154856)
                .build();
    }

    private String translateResultToJson(CheckPermissionsResult result) {
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        sb.append("[");
        for (CheckPermissionsResult.CheckPermissionResultInner resultInner : result.getCheckPermissionResults()) {
            if (first) {
                first = false;
            } else {
                sb.append(",");
            }
            sb.append("{\"permission name\":\"").append(resultInner.getPermissionName()).append("\",\"accessible\":\"")
                    .append(resultInner.isAccessible()).append("\"}");
        }
        sb.append("]");
        return sb.toString();
    }
}
