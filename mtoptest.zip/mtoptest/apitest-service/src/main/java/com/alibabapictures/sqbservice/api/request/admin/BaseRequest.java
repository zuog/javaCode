/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibabapictures.sqbservice.api.request.admin;

import java.io.Serializable;

/**
 * 类BaseRequest.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月15日 下午6:38:38
 */
public class BaseRequest implements Serializable {

    private static final long serialVersionUID = -3052057284719745953L;

    /**
     * token
     */
    private String            token;

    /**
     * 内部为工号，外部为账号
     */
    private String            account          = "123453";

    private int               pageIndex;

    private int               pageSize;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public int getPageIndex() {
        if (pageIndex <= 0) {
            // 设定默认
            pageIndex = 1;
        }
        return pageIndex;
    }

    public void setPageIndex(int pageIndex) {
        this.pageIndex = pageIndex;
    }

    public int getPageSize() {
        if (pageSize <= 0) {
            // 设定默认
            pageSize = 20;
        }
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
}