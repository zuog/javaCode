/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibabapictures.sqbservice.service;

import com.alibabapictures.sqbservice.module.MerchantDO;
import org.springframework.stereotype.Component;

/**
 * 类MerchantService.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月13日 下午6:59:05
 */
@Component
public interface MerchantService {

    /**
     * 商家基本信息存储
     * 
     * @param merchantDO 商家基本信息
     * @return
     */
    long save(MerchantDO merchantDO);

    /**
     * 根据商家id查询商家基本信息
     * 
     * @param id 商家id
     * @return
     */
    MerchantDO getById(long id);

    /**
     * 商家创建（同时创建商家对应账户）
     * 
     * @param loginName 登录名
     * @param phone 绑定手机号
     * @return
     */
    long create(String loginName, String phone);
}
