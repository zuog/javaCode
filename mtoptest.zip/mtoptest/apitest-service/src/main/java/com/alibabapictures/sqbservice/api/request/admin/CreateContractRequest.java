/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibabapictures.sqbservice.api.request.admin;

/**
 * 类CreateContractRequest.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月15日 下午6:38:06
 */
public class CreateContractRequest extends BaseRequest {


    /**
     * 
     */
    private static final long serialVersionUID = -6429752289695408981L;

    private String ipId;

    /**
     * 商家账号名称
     */
    private String merchantLoginName;

    /**
     * 商家手机号
     */
    private String merchantPhone;

    /**
     * 类目叶子节点数组。
     */
    private String leafCategoryIdList;

    /**
     * 保底销售金额。单位：分。
     */
    private String minimumSaleAmount;

    /**
     * 保底分成金额。单位：分。
     */
    private String minimumShareAmount;

    /**
     * 分佣模式。0：普通分佣 1：阶梯分佣
     */
    private String commissionType;

    /**
     * 当分佣模式为阶梯分佣的时候必输。 用json表示，两个key：amount（该阶梯上限金额，单位：分）和ratio（阶梯分佣比例。百分之xx。）。
     */
    private String ladderCommissionList;

    /**
     * 保底佣金比例。100为分母的分子部分。
     */
    private String minimumRatio;

    /**
     * 超额佣金比例。100为分母的分子部分。
     */
    private String overfulfilRatio;

    /**
     * 授权开始时间。格式yyyy-mm-dd
     */
    private String authorizationStartTime;

    /**
     * 授权结束时间。格式yyyy-mm-dd
     */
    private String authorizationEndTime;

    /**
     * 清货结束时间。格式yyyy-mm-dd
     */
    private String clearanceEndTime;

    /**
     * 授权渠道id列表，用json数组表示
     */
    private String channelIdList;

    /**
     * 其他授权渠道
     */
    private String otherChannel;

    /**
     * 备注
     */
    private String remark;

    public String getIpId() {
        return ipId;
    }

    public void setIpId(String ipId) {
        this.ipId = ipId;
    }

    public String getMerchantLoginName() {
        return merchantLoginName;
    }

    public void setMerchantLoginName(String merchantLoginName) {
        this.merchantLoginName = merchantLoginName;
    }

    public String getMerchantPhone() {
        return merchantPhone;
    }

    public void setMerchantPhone(String merchantPhone) {
        this.merchantPhone = merchantPhone;
    }

    public String getLeafCategoryIdList() {
        return leafCategoryIdList;
    }

    public void setLeafCategoryIdList(String leafCategoryIdList) {
        this.leafCategoryIdList = leafCategoryIdList;
    }

    public String getMinimumSaleAmount() {
        return minimumSaleAmount;
    }

    public void setMinimumSaleAmount(String minimumSaleAmount) {
        this.minimumSaleAmount = minimumSaleAmount;
    }

    public String getMinimumShareAmount() {
        return minimumShareAmount;
    }

    public void setMinimumShareAmount(String minimumShareAmount) {
        this.minimumShareAmount = minimumShareAmount;
    }

    public String getCommissionType() {
        return commissionType;
    }

    public void setCommissionType(String commissionType) {
        this.commissionType = commissionType;
    }

    public String getLadderCommissionList() {
        return ladderCommissionList;
    }

    public void setLadderCommissionList(String ladderCommissionList) {
        this.ladderCommissionList = ladderCommissionList;
    }

    public String getMinimumRatio() {
        return minimumRatio;
    }

    public void setMinimumRatio(String minimumRatio) {
        this.minimumRatio = minimumRatio;
    }

    public String getOverfulfilRatio() {
        return overfulfilRatio;
    }

    public void setOverfulfilRatio(String overfulfilRatio) {
        this.overfulfilRatio = overfulfilRatio;
    }

    public String getAuthorizationStartTime() {
        return authorizationStartTime;
    }

    public void setAuthorizationStartTime(String authorizationStartTime) {
        this.authorizationStartTime = authorizationStartTime;
    }

    public String getAuthorizationEndTime() {
        return authorizationEndTime;
    }

    public void setAuthorizationEndTime(String authorizationEndTime) {
        this.authorizationEndTime = authorizationEndTime;
    }

    public String getClearanceEndTime() {
        return clearanceEndTime;
    }

    public void setClearanceEndTime(String clearanceEndTime) {
        this.clearanceEndTime = clearanceEndTime;
    }

    public String getChannelIdList() {
        return channelIdList;
    }

    public void setChannelIdList(String channelIdList) {
        this.channelIdList = channelIdList;
    }

    public String getOtherChannel() {
        return otherChannel;
    }

    public void setOtherChannel(String otherChannel) {
        this.otherChannel = otherChannel;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
