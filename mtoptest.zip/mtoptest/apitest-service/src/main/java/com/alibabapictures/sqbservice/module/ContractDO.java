/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibabapictures.sqbservice.module;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.ylb.service.api.enums.ContractAuthorizationFileStatusEnum;
import com.alibaba.ylb.service.api.enums.ContractCommissionTypeEnum;
import com.alibaba.ylb.service.api.enums.ContractInvoiceStatusEnum;
import com.alibaba.ylb.service.api.enums.ContractMatchPayerEnum;
import com.alibaba.ylb.service.api.enums.ContractPayDelegationFileStatusEnum;
import com.alibaba.ylb.service.api.enums.ContractPayStatusEnum;
import com.alibaba.ylb.service.api.enums.ContractStatusEnum;

/**
 * 类ContractDO.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午1:56:23
 */
public class ContractDO implements Serializable {

    /**
     * 
     */
    private static final long                   serialVersionUID = 8731821367849090961L;

    /**
     * 主键
     */
    private Long                                id;

    /**
     * 创建时间
     */
    private Date                                gmtCreate;

    /**
     * 修改时间
     */
    private Date                                gmtModified;

    /**
     * 签约状态。0：未签约；1：已签约。
     */
    private ContractStatusEnum                  status;

    /**
     * 合同扫描件。这里存储文件的id。
     */
    private String                              scanningCopyFile;

    /**
     * 合同编号。
     */
    private String                              number;

    /**
     * 付款凭证。这里存储文件的id。
     */
    private String                              payEvidenceFile;

    /**
     * 付款状态。0：未付款；1：已付款。
     */
    private ContractPayStatusEnum               payStatus;

    /**
     * 关联ip表。
     */
    private Long                                ipId;

    /**
     * 商家id
     */
    private Long                                merchantId;

    /**
     * 保底销售金额。单位：分。
     */
    private Long                                minimumSaleAmount;

    /**
     * 保底分成金额。单位：分。
     */
    private Long                                minimumShareAmount;

    /**
     * 分佣模式。0：普通分佣 1：阶梯分佣
     */
    private ContractCommissionTypeEnum          commissionType;

    /**
     * 保底佣金比例。以万为分母的分子值。比如7%，在这里用700表示。
     */
    private Integer                             minimumRatio;

    /**
     * 超额佣金比例。以万为分母的分子值。比如7%，在这里用700表示。
     */
    private Integer                             overfulfilRatio;

    /**
     * 授权开始时间
     */
    private Date                                gmtAuthorizationStart;

    /**
     * 授权结束时间
     */
    private Date                                gmtAuthorizationEnd;

    /**
     * 清货期结束时间。
     */
    private Date                                gmtClearance;

    /**
     * 创建者的工号
     */
    private String                              creator;

    /**
     * 授权书。填充好变量的富文本。商家提交商家信息之后，随即重新生成该值。
     */
    private String                              authorizationFile;

    /**
     * 授权书状态。0：未寄送；1：已签收。
     */
    private ContractAuthorizationFileStatusEnum authorizationFileStatus;

    /**
     * 最后修改人的工号。
     */
    private String                              lastModifier;

    /**
     * 合同主体和付款主体是否相同。0：否；1：是。
     */
    private ContractMatchPayerEnum              contractMatchPayer;

    /**
     * 付款委托书。这里存储文件的id。
     */
    private String                              payDelegationFile;

    /**
     * 付款委托书状态。0：无需提交（表示合同主体和付款主体相同）、1：待提交:2：待审核:3：通过、4：不通过。
     */
    private ContractPayDelegationFileStatusEnum payDelegationFileStatus;

    /**
     * 其他授权渠道
     */
    private String                              otherChannel;

    /**
     * 发票状态。0：未寄送；1：已寄送。
     */
    private ContractInvoiceStatusEnum           invoiceStatus;

    /**
     * 备注
     */
    private String                              remark;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public ContractStatusEnum getStatus() {
        return status;
    }

    public void setStatus(ContractStatusEnum status) {
        this.status = status;
    }

    public String getScanningCopyFile() {
        return scanningCopyFile;
    }

    public void setScanningCopyFile(String scanningCopyFile) {
        this.scanningCopyFile = scanningCopyFile;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPayEvidenceFile() {
        return payEvidenceFile;
    }

    public void setPayEvidenceFile(String payEvidenceFile) {
        this.payEvidenceFile = payEvidenceFile;
    }

    public ContractPayStatusEnum getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(ContractPayStatusEnum payStatus) {
        this.payStatus = payStatus;
    }

    public Long getIpId() {
        return ipId;
    }

    public void setIpId(Long ipId) {
        this.ipId = ipId;
    }

    public Long getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Long merchantId) {
        this.merchantId = merchantId;
    }

    public Long getMinimumSaleAmount() {
        return minimumSaleAmount;
    }

    public void setMinimumSaleAmount(Long minimumSaleAmount) {
        this.minimumSaleAmount = minimumSaleAmount;
    }

    public Long getMinimumShareAmount() {
        return minimumShareAmount;
    }

    public void setMinimumShareAmount(Long minimumShareAmount) {
        this.minimumShareAmount = minimumShareAmount;
    }

    public ContractCommissionTypeEnum getCommissionType() {
        return commissionType;
    }

    public void setCommissionType(ContractCommissionTypeEnum commissionType) {
        this.commissionType = commissionType;
    }

    public Integer getMinimumRatio() {
        return minimumRatio;
    }

    public void setMinimumRatio(Integer minimumRatio) {
        this.minimumRatio = minimumRatio;
    }

    public Integer getOverfulfilRatio() {
        return overfulfilRatio;
    }

    public void setOverfulfilRatio(Integer overfulfilRatio) {
        this.overfulfilRatio = overfulfilRatio;
    }

    public Date getGmtAuthorizationStart() {
        return gmtAuthorizationStart;
    }

    public void setGmtAuthorizationStart(Date gmtAuthorizationStart) {
        this.gmtAuthorizationStart = gmtAuthorizationStart;
    }

    public Date getGmtAuthorizationEnd() {
        return gmtAuthorizationEnd;
    }

    public void setGmtAuthorizationEnd(Date gmtAuthorizationEnd) {
        this.gmtAuthorizationEnd = gmtAuthorizationEnd;
    }

    public Date getGmtClearance() {
        return gmtClearance;
    }

    public void setGmtClearance(Date gmtClearance) {
        this.gmtClearance = gmtClearance;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public String getAuthorizationFile() {
        return authorizationFile;
    }

    public void setAuthorizationFile(String authorizationFile) {
        this.authorizationFile = authorizationFile;
    }

    public ContractAuthorizationFileStatusEnum getAuthorizationFileStatus() {
        return authorizationFileStatus;
    }

    public void setAuthorizationFileStatus(ContractAuthorizationFileStatusEnum authorizationFileStatus) {
        this.authorizationFileStatus = authorizationFileStatus;
    }

    public String getLastModifier() {
        return lastModifier;
    }

    public void setLastModifier(String lastModifier) {
        this.lastModifier = lastModifier;
    }

    public ContractMatchPayerEnum getContractMatchPayer() {
        return contractMatchPayer;
    }

    public void setContractMatchPayer(ContractMatchPayerEnum contractMatchPayer) {
        this.contractMatchPayer = contractMatchPayer;
    }

    public String getPayDelegationFile() {
        return payDelegationFile;
    }

    public void setPayDelegationFile(String payDelegationFile) {
        this.payDelegationFile = payDelegationFile;
    }

    public ContractPayDelegationFileStatusEnum getPayDelegationFileStatus() {
        return payDelegationFileStatus;
    }

    public void setPayDelegationFileStatus(ContractPayDelegationFileStatusEnum payDelegationFileStatus) {
        this.payDelegationFileStatus = payDelegationFileStatus;
    }

    public String getOtherChannel() {
        return otherChannel;
    }

    public void setOtherChannel(String otherChannel) {
        this.otherChannel = otherChannel;
    }

    public ContractInvoiceStatusEnum getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(ContractInvoiceStatusEnum invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public String toString() {
        return "ContractDO [id=" + id + "]";
    }
}
