/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibabapictures.sqbservice.module;

import java.io.Serializable;
import java.util.Date;

import com.alibaba.ylb.service.api.enums.WhetherEnum;

/**
 * 类MerchantDO.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月13日 上午11:47:22
 */
public class MerchantDO implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 6664866142741788161L;

    /**
     * id
     */
    private Long              id;

    /**
     * 创建时间
     */
    private Date              gmtCreate;

    /**
     * 修改时间
     */
    private Date              gmtModified;

    /**
     * 公司注册登记名称
     */
    private String            name;

    /**
     * 纳税人识别号
     */
    private String            taxNo;

    /**
     * 注册号
     */
    private String            regitserNo;

    /**
     * 是否为增值税一般纳税人（0否，1是）
     */
    private WhetherEnum       valueAddTax;

    /**
     * 一般纳税人证明附件信息
     */
    private String            taxProveFile;

    /**
     * 开户行
     */
    private String            bankName;

    /**
     * 开户账号
     */
    private String            bankNo;

    /**
     * 公司地址
     */
    private String            address;

    /**
     * 公司电话
     */
    private String            phone;

    /**
     * 发票寄送地址
     */
    private String            invoiceAddress;

    /**
     * 收件人及电话
     */
    private String            contactInfo;

    public MerchantDO(){

    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }


    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTaxNo() {
        return taxNo;
    }

    public void setTaxNo(String taxNo) {
        this.taxNo = taxNo;
    }

    public String getRegitserNo() {
        return regitserNo;
    }

    public void setRegitserNo(String regitserNo) {
        this.regitserNo = regitserNo;
    }

    public WhetherEnum getValueAddTax() {
        return valueAddTax;
    }

    public void setValueAddTax(WhetherEnum valueAddTax) {
        this.valueAddTax = valueAddTax;
    }

    public String getTaxProveFile() {
        return taxProveFile;
    }

    public void setTaxProveFile(String taxProveFile) {
        this.taxProveFile = taxProveFile;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankNo() {
        return bankNo;
    }

    public void setBankNo(String bankNo) {
        this.bankNo = bankNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getInvoiceAddress() {
        return invoiceAddress;
    }

    public void setInvoiceAddress(String invoiceAddress) {
        this.invoiceAddress = invoiceAddress;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    @Override
    public String toString() {
        return "Merchant [id=" + id + ", gmtCreate=" + gmtCreate + ", gmtModified=" + gmtModified + ", name=" + name + ", taxNo=" + taxNo + ", regitserNo=" + regitserNo + ", valueAddTax=" + valueAddTax
               + ", taxProveFile=" + taxProveFile + ", bankName=" + bankName + ", bankNo=" + bankNo + ", address=" + address + ", phone=" + phone + ", invoiceAddress=" + invoiceAddress + ", contactInfo=" + contactInfo
               + "]";
    }

}
