/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibabapictures.sqbservice;

import com.alibaba.ylb.mtop.tddl.mybatis.MerchantMapper;

import com.alibabapictures.sqbservice.module.MerchantDO;
import com.alibabapictures.sqbservice.service.MerchantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 类MerchantServiceImpl.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月13日 下午8:25:05
 */
@Component
public class MerchantServiceImpl implements MerchantService {

    @Autowired
    private MerchantMapper         merchantMapper;


    @Override
    public long save(MerchantDO merchantDO) {
        merchantMapper.save(merchantDO);
        return merchantDO.getId();
    }

    @Override
    public MerchantDO getById(long id) {
        return merchantMapper.getById(id);
    }

    /*
     * (non-Javadoc)
     * @see com.alibabapictures.sqbservice.service.MerchantService#create(java.lang.String, java.lang.String)
     */
    @Override
    public long create(String loginName, String phone) {
        // TODO Auto-generated method stub
        return 0;
    }

}