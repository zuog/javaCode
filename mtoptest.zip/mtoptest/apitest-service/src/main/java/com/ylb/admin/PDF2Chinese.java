package com.ylb.admin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfWriter;

/**
 * 类PDF2Chinese的实现描述：
 *
 * @author lingce 17/11/21 上午10:59
 */
public class PDF2Chinese {

    public static void main(String[] args) throws DocumentException, IOException
    {
        Document document = new Document();
        OutputStream os = new FileOutputStream(new File("chinese.pdf"));
        PdfWriter.getInstance(document,os);
        document.open();
        //方法一：使用Windows系统字体(TrueType)
        //BaseFont baseFont = BaseFont.createFont("C:/Windows/Fonts/SIMYOU.TTF",BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED);

        //方法二：使用iTextAsian.jar中的字体
        //BaseFont baseFont = BaseFont.createFont("STSong-Light",BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED);

        //方法三：使用资源字体(ClassPath)
        ////BaseFont baseFont = BaseFont.createFont("/SIMYOU.TTF",BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED);

        // pdf 文档中文字符处理
        Font bf = new Font(BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", true));
        //Font font = new Font(bf);
        document.add(new Paragraph("解决中文问题了！",bf));
        document.close();
    }
}
