package com.ylb.admin;

import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import com.alibaba.fastjson.JSON;

import com.taobao.common.tfs.TfsManager;
import org.icepdf.core.exceptions.PDFException;
import org.icepdf.core.exceptions.PDFSecurityException;
import org.icepdf.core.pobjects.Document;
import org.icepdf.core.util.GraphicsRenderingHints;

/**
 * 类PDF2IMGTest的实现描述：
 *
 * @author lingce 17/11/21 下午4:49
 */
public class PDF2IMGTest {

    @Resource
    private TfsManager tfsManager;
    public static List<String>  PDF2IMG(String filePath) {
        List<String> pdfCdnUrl = new ArrayList<>();
        //String filePath = "/home/admin/deylbservice/conf/pdf/aliyun.pdf";

        //File file1 = new File(filePath);


        try {
            String decodeUrl = URLDecoder.decode(filePath,"utf-8");
            System.out.println("#########decodeUrl= " + decodeUrl);

            //String encodeUrl = URLEncoder.encode(filePath,"utf-8");
            //System.out.println("#########encodeUrl= " + encodeUrl);
            URL inputURL = new URL(decodeUrl);
            InputStream inputStream = inputURL.openStream();

            Document document = new Document();
            document.setInputStream(inputStream,"");
            // 缩放比例（大图）
            float scale = 2f;
            // 缩放比例（小图）
            // float scale = 0.2f;
            // 旋转角度
            float rotation = 0f;
            for (int i = 0; i < document.getNumberOfPages(); i++) {
                BufferedImage image = (BufferedImage) document.getPageImage(i,
                    GraphicsRenderingHints.SCREEN,
                    org.icepdf.core.pobjects.Page.BOUNDARY_CROPBOX,
                    rotation, scale);
                RenderedImage rendImage = image;
                try {
                    File file = new File("/home/admin/deylbservice/conf/pdf/" + i + ".jpg");
                    // 这里png作用是：格式是jpg但有png清晰度
                    ImageIO.write(rendImage, "png", file);

                    String outPath = "/home/admin/deylbservice/conf/pdf/" + i +".jpg";
                    //pdfCdnUrl = uploadToCdn(outPath, ".pdf");
                    System.out.println("##############pdfCdnUrl:"+ outPath);
                    pdfCdnUrl.add(outPath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                image.flush();
            }

            document.dispose();
            return pdfCdnUrl;
        } catch (PDFException e1) {
            e1.printStackTrace();
        } catch (PDFSecurityException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        System.out.println("======================完成============================");
        return  pdfCdnUrl;
    }

    protected String uploadToCdn(String localFileName, String fileExtName) throws IOException {
        byte[] bytes = getContent(localFileName);
        String uploadFileName = tfsManager.saveFile(bytes, null, fileExtName, true);
        return TfsHelper.buildTfsCdnUrl(uploadFileName);
    }

    /**
     * 读取文件内容
     *
     * @param filePath
     * @return
     * @throws IOException
     */
    @SuppressWarnings("resource")
    protected byte[] getContent(String filePath) throws IOException {
        File file = new File(filePath);
        long fileSize = file.length();
        if (fileSize > Integer.MAX_VALUE) {
            return null;
        }
        FileInputStream fi = new FileInputStream(file);
        byte[] buffer = new byte[(int) fileSize];
        int offset = 0;
        int numRead = 0;
        while (offset < buffer.length && (numRead = fi.read(buffer, offset, buffer.length - offset)) >= 0) {
            offset += numRead;
        }
        if (offset != buffer.length) {
            throw new IOException("Could not completely read file " + file.getName());
        }
        fi.close();
        return buffer;
    }

    public static void main(String[] args) {
        //String filePath = "/home/admin/deylbservice/conf/pdf/aliyun.pdf";
        String filePath = "https://sqbbe.oss-cn-beijing.aliyuncs.com/activityFile/45/1511407238181%E5%BD%B1%E8%A7%86%E6%B6%88%E8%B4%B9%E6%9D%83%E7%9B%8A%E8%B4%AD%E4%B9%B0%E5%8D%8F%E8%AE%AE.pdf";
        List<String> a = PDF2IMG(filePath);
        System.out.println("==============="+ JSON.toJSONString(a));
    }
}
