package com.ylb.admin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Component;

/**
 * 类TfsHelper.java的实现描述：TfsHelper.java
 * @author lujun.xlj Jan 6, 2017 1:43:44 PM
 */
@Component("tfsHelper")
public class TfsHelper {

    private static Map<String, Object>
        proMap												= new ConcurrentHashMap<String, Object>();
    /**
     * 生成CDN地址
     *
     * @param tfsName
     * @return
     */
    public static String buildTfsCdnUrl(String tfsName) {
        List<String> servers = null;
        String list = getStringValue("deylb.cdnserver.url.list", "img1.tbcdn.cn,img2.tbcdn.cn,img3.tbcdn.cn,img4.tbcdn.cn");
        if ("".equals(list)) {
            servers = new ArrayList<String>();
        } else {
            servers = new ArrayList<String>(Arrays.asList(list.split(",")));
        }
        if (servers.size() == 0) {
            throw new RuntimeException("图片服务器列表为空");
        }
        int i = Long.valueOf(System.currentTimeMillis() % servers.size()).intValue();
        return new StringBuilder("//").append(servers.get(i)).append("/tfscom/").append(tfsName).toString();
    }

    public static String getStringValue(String key, String defaultValue) {
        Object obj = getDiamondKey(key);
        if (obj == null) {
            return defaultValue;
        }
        return obj.toString();
    }

    public static Object getDiamondKey(String key) {
        return proMap.get(key);
    }

}
