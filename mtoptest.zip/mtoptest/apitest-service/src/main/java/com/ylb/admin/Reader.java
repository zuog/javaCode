package com.ylb.admin;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * 类Reader的实现描述：
 *
 * @author lingce 17/12/12 下午5:14
 */
public class Reader {
    //public static void main(String args[]) throws IOException {
    //    //创建可容纳 1000 个字符的数组
    //    char a[]=new char[10000];
    //
    //    FileReader b=new FileReader("apitest-start/src/main/resources/doc2.txt");
    //    //将数据读入到数组 a 中，并返回字符数
    //    int num=b.read(a);
    //
    //    //将字符串数组转换成字符串
    //    String str=new String(a,0,num);
    //
    //    System.out.println("读取的字符个数为："+num+",内容为：\n");
    //    System.out.println(str);
    //}

    //public static void main(String args[]) throws IOException{
    //    String OneLine;
    //    int count=0;
    //    try{
    //        FileReader a=new FileReader("apitest-start/src/main/resources/doc2.txt");
    //        BufferedReader b=new BufferedReader(a);
    //        while((OneLine=b.readLine())!=null){  //每次读取 1 行
    //            count++;  //计算读取的行数
    //            System.out.println(OneLine);
    //        }
    //        System.out.println("\n 共读取了"+count+"行");
    //        b.close();
    //    }
    //    catch(IOException io){
    //        System.out.println("出错了!"+io);
    //    }
    //}

    //public static void main(String args[]){
    //    try{
    //        FileWriter a=new FileWriter("apitest-start/src/main/resources/doc2.txt",true);
    //        for(int i=32;i<126;i++){
    //            a.write(i);
    //        }
    //        a.close();
    //    }
    //    catch(IOException e){}
    //}
    //
    //public static void main(String args[]){
    //    String str=new String();
    //    try{
    //        BufferedReader in=new BufferedReader(new FileReader("apitest-start/src/main/resources/doc2.txt"));
    //        BufferedWriter out=new BufferedWriter(new FileWriter("apitest-start/src/main/resources/doc3.txt"));
    //        while((str=in.readLine())!=null){
    //            System.out.println(str);
    //            out.write(str);  //将读取到的 1 行数据写入输出流
    //            out.newLine();  //写入换行符
    //        }
    //        out.flush();
    //        in.close();
    //        out.close();
    //    }
    //    catch(IOException e){
    //        System.out.println("出现错误"+e);
    //    }
    //}

    //public static void main(String args[]){
    //    char ch;
    //    int data;
    //    try{
    //        FileInputStream a=new FileInputStream(FileDescriptor.in);  //创建文件输入流对象
    //        FileOutputStream b=new FileOutputStream("apitest-start/src/main/resources/doc3.txt");  //创建文件输出流对象
    //        System.out.println("请输入字符，以#号结束：");
    //        while((ch=(char)a.read())!='#'){
    //            b.write(ch);
    //        }
    //        a.close();
    //        b.close();
    //        System.out.println();
    //        FileInputStream c=new FileInputStream("apitest-start/src/main/resources/doc3.txt");
    //        FileOutputStream d=new FileOutputStream(FileDescriptor.out);
    //        while(c.available()>0){
    //            data=c.read();
    //            d.write(data);
    //        }
    //        c.close();d.close();
    //    }
    //    catch(FileNotFoundException e){
    //        System.out.println("找不到该文件！");
    //    }
    //    catch(IOException e){}
    //}

    //public static void main(String args[]){
    //    String fileName="ep10_7.dat";
    //    int value1=100,value2=0,value3=-100;
    //    try{
    //        //将 DataOutputStream 与 FileOutputStream 连接输出不同类型的数据
    //        DataOutputStream a=new DataOutputStream(new FileOutputStream(fileName));
    //        a.writeInt(value1);
    //        a.writeInt(value2);
    //        a.writeInt(value3);
    //        a.close();
    //    }
    //    catch(IOException i){
    //        System.out.println("出现错误!"+fileName);
    //    }
    //}

    //public static void main(String args[]){
    //    String fileName="D:\\myjava/ep10_7.dat";
    //    int sum=0;
    //    try{
    //        DataInputStream a=new DataInputStream(new BufferedInputStream(new FileInputStream(fileName)));
    //        sum+=a.readInt();
    //        sum+=a.readInt();
    //        sum+=a.readInt();
    //        System.out.println("三个数的和为："+sum);
    //        a.close();
    //    }
    //    catch(IOException e){
    //        System.out.println("出现错误！"+fileName);
    //    }
    //}

    //public static void main(String args[]) {
    //    try {
    //        byte a[] = new byte[128];
    //        //设置输入缓冲区
    //        System.out.print("请输入字符串：");
    //        int count = System.in.read(a);
    //        //读取标准输入输出流
    //        System.out.println("输入的是：");
    //        for (int i = 0; i < count; i++) {System.out.print(a[i] + "");}
    //        //输出数组元素的 ASCII 值
    //        System.out.println();
    //        for (int i = 0; i < count - 2; i++)
    //        //不显示回车和换行符
    //        { System.out.print((char)a[i] + ""); }
    //        //按字符方式输出元素
    //        System.out.println();
    //        System.out.println("输入的字符个数为：" + count);
    //        Class InClass = System.in.getClass();
    //        Class OutClass = System.out.getClass();
    //        System.out.println("in 所在的类为：" + InClass.toString());
    //        System.out.println("out 所在的类为：" + OutClass.toString());
    //    } catch (IOException e) {}
    //}

    //public static void main(String args[]) throws IOException {
    //    String FilePath;
    //    InputStreamReader in = new InputStreamReader(System.in);
    //    BufferedReader a = new BufferedReader(in);
    //    System.out.println("请输入一个绝对路径：");
    //    //将 FilePath 作为输入值
    //    FilePath = a.readLine();
    //    //获得此路径的文件名称
    //    File FileName = new File(FilePath);
    //    //判断此文件是否为目录
    //    if (FileName.isDirectory()) {
    //        System.out.println((FileName.getName()) + "为一个目录");
    //        System.out.println("================");
    //        //将目录下所有文件存入数组
    //        File FileList[] = FileName.listFiles();
    //        for (int i = 0; i < FileList.length; i++) {
    //            //判断是否为隐藏文件
    //            if (FileList[i].isHidden() == false) {
    //                //输出非隐藏文件
    //                System.out.println(FileList[i].getName());
    //            }
    //        }
    //    } else {
    //        System.out.println((FileName.getName()) + "为一个文件");
    //        System.out.println("================");
    //        //获得文件绝对路径
    //        System.out.println("绝对路径为：" + FileName.getAbsolutePath());
    //        //判断此文件是否可读取
    //        System.out.println(FileName.canRead() ? "可读取" : "不可读取");
    //        //判断此文件是否可修改
    //        System.out.println(FileName.canWrite() ? "可修改" : "不可修改");
    //        //判断此文件是否为隐藏
    //        System.out.println(FileName.isHidden() ? "为隐藏文件" : "非隐藏文件");
    //    }
    //}

    public static void main(String args[]) throws IOException {
        FileOutputStream a=new FileOutputStream("ep10_13.zip");
        //处理压缩文件
        ZipOutputStream out=new ZipOutputStream(new BufferedOutputStream(a));
        for(int i=0;i<args.length;i++){  //对命令行输入的每个文件进行处理
            System.out.println("Writing file"+args[i]);
            BufferedInputStream in=new BufferedInputStream(new FileInputStream(args[i]));
            out.putNextEntry(new ZipEntry(args[i]));  //设置 ZipEntry 对象
            int b;
            while((b=in.read())!=-1)
                out.write(b);  //从源文件读出，往压缩文件中写入
            in.close();
        }
        out.close();
        //解压缩文件并显示
        System.out.println("Reading file");
        FileInputStream d=new FileInputStream("ep10_13.zip");
        ZipInputStream inout=new  ZipInputStream(new BufferedInputStream(d));
        ZipEntry z;

        while((z=inout.getNextEntry())!=null){  //获得入口
            System.out.println("Reading file"+z.getName());  //显示文件初始名
            int x;
            while((x=inout.read())!=-1)
                System.out.write(x);
            System.out.println();
        }
        inout.close();
    }
}
