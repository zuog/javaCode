//package com.ylb.admin;
//
///**
// * 类TEST的实现描述：
// *
// * @author lingce 17/11/22 下午4:24
// */
//public class TEST {
//
//
//
//    public static void main(String[] args) {
//        // TODO Auto-generated method stub
//        try {
//            ConvertPagesToHiResImages test =  new ConvertPagesToHiResImages("jpg",
//                "/home/admin/deylbservice/conf/pdf/atest_pdf.signed.613.pdf");
//        } catch (Exception e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//    }
//}
