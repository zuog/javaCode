package com.ylb.admin;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.Method;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.security.AccessController;
import java.security.PrivilegedAction;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGEncodeParam;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import com.sun.pdfview.PDFFile;
import com.sun.pdfview.PDFPage;
import org.icepdf.core.pobjects.Document;

/**
 * 类PDFchangToImage的实现描述：
 *
 * @author lingce 17/11/21 上午10:33
 */
public class PDFchangToImage {

    public static String pdf2Png() {
        int countPage = 0 ;
        try{
            String instructiopath = "/home/admin/deylbservice/conf/pdf/aliyun.pdf";
            File file = new File(instructiopath);
            RandomAccessFile raf = new RandomAccessFile(file,"r");
            FileChannel channel = raf.getChannel();
            MappedByteBuffer buf = channel.map(MapMode.READ_ONLY,0,channel.size());
            PDFFile pdfFile = new PDFFile(buf);
            // 获得图片页数
            countPage = pdfFile.getNumPages();
            for (int i = 1; i <= countPage; i++) {
                PDFPage page = pdfFile.getPage(i);
                Rectangle rect = new Rectangle(0, 0, ((int) page.getBBox().getWidth()), ((int) page.getBBox().getHeight()));
                /** 图片清晰度（n>0且n<7）【pdf放大参数】 */
                int n = 2;

                Image img = page.getImage(rect.width * n, rect.height * n, rect, null, true, true);
                BufferedImage tag = new BufferedImage(rect.width * n, rect.height * n, BufferedImage.TYPE_INT_RGB);
                tag.getGraphics().drawImage(img, 0, 0, rect.width * n, rect.height * n, null);
                /**
                 * File imgfile = new File("D:\\work\\mybook\\FilesNew\\img\\" +
                 * i + ".jpg"); if(imgfile.exists()){
                 * if(imgfile.createNewFile()) { System.out.println("创建图片："+
                 * "D:\\work\\mybook\\FilesNew\\img\\" + i + ".jpg"); } else {
                 * System.out.println("创建图片失败！"); } }
                 */
                FileOutputStream out = new FileOutputStream("/home/admin/deylbservice/conf/pdf/" + i + ".png");
                /** 输出到文件流 */
                JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
                JPEGEncodeParam param2 = encoder.getDefaultJPEGEncodeParam(tag);
                param2.setQuality(1f, true);
                /** 1f~0.01f是提高生成的图片质量 */
                encoder.setJPEGEncodeParam(param2);
                encoder.encode(tag);
                /** JPEG编码 */
                out.close();
            }
            channel.close();
            raf.close();
            //unmap(buf);
            /** 如果要在转图片之后删除pdf，就必须要这个关闭流和清空缓冲的方法 */



        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  String.valueOf(countPage);
    }

    @SuppressWarnings("unchecked")
    public static void unmap(final Object buffer) {
        AccessController.doPrivileged(new PrivilegedAction() {
            @Override
            public Object run() {
                try {
                    Method getCleanerMethod = buffer.getClass().getMethod(
                        "cleaner", new Class[0]);
                    getCleanerMethod.setAccessible(true);
                    sun.misc.Cleaner cleaner = (sun.misc.Cleaner) getCleanerMethod
                        .invoke(buffer, new Object[0]);
                    cleaner.clean();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        });
    }


    public static void main(String[] args){
        //String a = pdf2Png();
        //System.out.println("##############"+a);
    try{
        Document document = new Document();
        File file = new File("/home/admin/deylbservice/conf/pdf/aliyun.pdf");
        InputStream in = new FileInputStream(file);
        document.setInputStream(in,"www.taobao.com");
        System.out.println(document);
    }catch (Exception e) {
        System.out.println("#########error##########");
    }

    }
}
