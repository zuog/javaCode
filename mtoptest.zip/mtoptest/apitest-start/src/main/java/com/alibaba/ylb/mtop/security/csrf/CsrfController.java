package com.alibaba.ylb.mtop.security.csrf;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.security.spring.component.csrf.CsrfTokenModel;

/**
 * 使用 @CsrfTokenModel("_csrfToken")生成csrftoken的例子，详见
 * http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-security-csrf
 * 
 * @author chengxu
 */
@Controller
@RequestMapping("/csrf")
@CsrfTokenModel("_csrfToken")
public class CsrfController {

    @RequestMapping("/form")
    public String form() {
        return "security/csrf/form";
    }

    @RequestMapping(value = "/submit", method = { RequestMethod.GET, RequestMethod.POST })
    public String submit(@RequestParam String name, Model model) {
        model.addAttribute("name", name);
        return "security/csrf/submit";
    }
}
