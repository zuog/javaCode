package com.alibaba.ylb.mtop.tair;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * tair的例子，直接注入TairManager，通过它进行tair的put和get操作。详情见
 * http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/ spring-boot-tair
 *
 * @author chengxu
 */
@Controller
public class TairController {

    @Autowired
    private TairProperties tairProperties;

    @RequestMapping(value = "/put", method = RequestMethod.POST)
    public @ResponseBody String put(@RequestParam(required = false) String key,
                                    @RequestParam(required = false) String value) {
        StringBuilder result = new StringBuilder("");
        try {
            if (key == null) {
                key = "defaultKey";
            }
            if (value == null) {
                value = "defaultValue";
            }
            String putResult = tairProperties.put(key, value) ? "success" : "fail";
            result.append("key : " + key);
            result.append("value : " + value);
            result.append("put result : " + putResult);
        } catch (Exception e) {
            result.append(" fail! ");
        }
        result.append("<br>");
        result.append("<hr>");
        result.append("[<a href=\"/tair\"> Dev Home </a>]");
        result.append("&nbsp");
        result.append("[<a href=\"/\"> Home </a>]");

        return result.toString();
    }

    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public @ResponseBody String delete(@RequestParam(required = false) String key) {
        StringBuilder result = new StringBuilder("");
        try {
            if (key == null) {
                key = "defaultKey";
            }
            String deleteResult = tairProperties.delete(key) ? "success" : "fail";
            result.append("delete : " + deleteResult);
        } catch (Exception e) {
            result.append(" fail! ");
        }
        result.append("<br>");
        result.append("<hr>");
        result.append("[<a href=\"/tair\"> Dev Home </a>]");
        result.append("&nbsp");
        result.append("[<a href=\"/\"> Home </a>]");

        return result.toString();
    }

    @RequestMapping(value = "/get", method = RequestMethod.POST)
    public @ResponseBody String get(@RequestParam(required = false) String key) {
        StringBuilder result = new StringBuilder("");
        try {
            if (key == null) {
                key = "defaultKey";
            }
            String value = tairProperties.get(key);
            result.append("get : " + value);
        } catch (Exception e) {
            result.append(" fail! ");
        }
        result.append("<br>");
        result.append("<hr>");
        result.append("[<a href=\"/tair\"> Dev Home </a>]");
        result.append("&nbsp");
        result.append("[<a href=\"/\"> Home </a>]");

        return result.toString();
    }
}
