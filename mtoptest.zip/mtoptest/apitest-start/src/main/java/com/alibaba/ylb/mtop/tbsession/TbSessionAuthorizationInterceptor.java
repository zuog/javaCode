package com.alibaba.ylb.mtop.tbsession;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.alibaba.boot.tbsession.config.auth.AbstractAuthorizationInterceptor;
import com.taobao.session.TaobaoSession;

/**
 * 登录授权自定义实现，详见tbsession文档：http://baike.corp.taobao.com/index.php/Tbsession
 *
 * @author chengxu
 */
@Service
public class TbSessionAuthorizationInterceptor extends AbstractAuthorizationInterceptor {

    /**
     * 判断是否登录
     */
    @Override
    public boolean authorize(HttpServletRequest request) {
        return TaobaoSession.isLogin();
    }

    @Override
    public void approve(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // has been logined, do your custom business here...
    }

    /**
     * 没有登陆，跳转到登陆页面
     */
    @Override
    public void deny(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        StringBuffer requestUrl = request.getRequestURL();
        if (StringUtils.isNotBlank(request.getQueryString())) {
            requestUrl.append("?").append(request.getQueryString());
        }
        String encodeUrl = URLEncoder.encode(requestUrl.toString(), "UTF-8");
        response.sendRedirect(properties.getAuthorizationLoginUrl() + "?redirectURL=" + encodeUrl);
    }
}
