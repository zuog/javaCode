package com.alibaba.ylb.mtop.alimonitor;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.alimonitor.jmonitor.plugin.spring.SpringMethodDataManager;
import com.alibaba.alimonitor.jmonitor.plugin.spring.SpringMethodItemKey;
import com.alibaba.alimonitor.jmonitor.plugin.spring.SpringMethodItemValue;
import com.alibaba.alimonitor.jmonitor.plugin.web.WebUrlDataManager;
import com.alibaba.alimonitor.jmonitor.plugin.web.WebUrlItem;

/**
 * AliMonitor监视, 详细使用方法见 http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-alimonitor
 *
 * @author chengxu
 */
@Controller
public class AliMonitorController {

    @Autowired
    private AliMonitorDemo alimonitorDemo;

    @RequestMapping("/exception")
    public @ResponseBody String exception() throws Exception {
        return alimonitorDemo.exception();
    }

    @RequestMapping("/normal")
    public @ResponseBody String normal() {
        return alimonitorDemo.normal();
    }

    /**
     * 显示alimonitor监视web url和方法调用的状态
     */
    @RequestMapping("/stats")
    public @ResponseBody String stats() {
        StringBuilder builder = new StringBuilder();
        builder.append("<h2>AliMonitor statistics</h2>");
        builder.append("<h3>URL</h3>");
        builder.append("<ul>");
        Map<String, WebUrlItem> webUrlMap = WebUrlDataManager.getInstance().getWebUrlMap();
        for (String url : webUrlMap.keySet()) {
            builder.append("<li>").append(url).append(": ").append(webUrlMap.get(url).getCount()).append("</li>");
        }
        builder.append("</ul>");
        builder.append("<h3>Method</h3>");
        builder.append("<ul>");
        Map<SpringMethodItemKey, SpringMethodItemValue> methodMap = SpringMethodDataManager.getInstance().getDataMap();
        for (SpringMethodItemKey method : methodMap.keySet()) {
            builder.append("<li>").append(method.getMethod()).append(": ")
                    .append(methodMap.get(method).getInvokCount()).append(" invocations, ")
                    .append(methodMap.get(method).getErrorCount()).append(" errors")
                    .append("</li>");
        }
        builder.append("</ul>");
        return builder.toString();
    }
}
