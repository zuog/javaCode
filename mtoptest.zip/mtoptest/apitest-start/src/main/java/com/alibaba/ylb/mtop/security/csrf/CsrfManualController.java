package com.alibaba.ylb.mtop.security.csrf;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 通过配置application.properties对url进行统一生成csrftoken的例子，详见
 * http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-security-csrf
 *
 * @author chengxu
 */
@Controller
@RequestMapping("csrf")
public class CsrfManualController {

    @Autowired
    private Environment env;

    @RequestMapping(value = { "/submit_manual" }, method = { RequestMethod.GET, RequestMethod.POST })
    public String msubmit(@RequestParam String name, Model model) {
        model.addAttribute("name", name);
        return "security/csrf/submit_manual";
    }

    @RequestMapping("/form_manual")
    public String mform() {
        return "security/csrf/form_manual";
    }

    @RequestMapping("/custom")
    public String custom(Model model) {
        model.addAttribute("env", env);
        return "security/csrf/custom";
    }
}
