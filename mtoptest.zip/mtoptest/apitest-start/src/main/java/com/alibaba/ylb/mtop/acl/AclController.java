package com.alibaba.ylb.mtop.acl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Acl许可信息
 *
 * @author chengxu
 */
@Controller
public class AclController {
    @Autowired
    public AclDemo aclDemo;

    @RequestMapping(value = "/acl/permissions", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody String checkPermission() {
        return aclDemo.checkPermission();
    }

}
