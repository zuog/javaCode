package com.alibaba.ylb.mtop.tbsession;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.taobao.session.TaobaoSession;

/**
 * tbsession的例子，其中参数中的HttpSession为tbsession实现的类, 详见
 * http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-tbsession
 *
 * @author chengxu
 */
@Controller
public class TbSessionController {

    @RequestMapping("/tbsession")
    public @ResponseBody String verifySession(HttpSession session) {
        if (session instanceof TaobaoSession) {
            session.setAttribute("reuslt", "success");
            return (String) session.getAttribute("reuslt");
        }

        return "No tbsession";
    }
}
