package com.alibaba.ylb.mtop.notify;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Notify发送消息
 *
 * @author chengxu
 */
@Controller
public class NotifyController {

    @Autowired
    @Qualifier("notify")
    private MessageProducer messageProducer;

    @RequestMapping(value = "/notify/message", method = RequestMethod.POST)
    public @ResponseBody String send(@RequestParam(required = false) String messageBody) {
        StringBuilder result = new StringBuilder("send");

        if (messageBody == null) {
            messageBody = "default message";
        }

        if (messageProducer.sendMessage(messageBody)) {
            result.append(" success! ");
        } else {
            result.append(" fail! ");
        }
        result.append("<br>");
        result.append("<hr>");
        result.append("[<a href=\"/notify\"> Dev Home </a>]");
        result.append("&nbsp");
        result.append("[<a href=\"/\"> Home </a>]");

        return result.toString();
    }
}
