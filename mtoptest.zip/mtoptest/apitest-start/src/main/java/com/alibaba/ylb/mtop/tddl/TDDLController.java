package com.alibaba.ylb.mtop.tddl;

import java.util.List;

import javax.annotation.Resource;

import com.alibaba.ylb.mtop.tddl.jdbc.JdbcQueryDemo;
import com.alibaba.ylb.mtop.tddl.mybatis.MybatisQueryDemo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * JdbcQueryDemo是直接注入JdbcTemplate的方式来访问数据库，MybatisQueryDemo是通过mybatis的方式访问数据库。
 * 通过mybatis进行查询的例子，详见http://www.mybatis.org/spring-boot-starter/mybatis-spring-boot-autoconfigure/
 * 
 * @author chengxu
 */
@Controller
public class TDDLController {

    // @Autowired
    @Resource
    private JdbcQueryDemo jdbcDemo;

    // @Autowired
    @Resource
    private MybatisQueryDemo mybatisDemo;

    @RequestMapping(value = "/jdbc/salary", method = RequestMethod.GET)
    public @ResponseBody String queryByJDBC() {
        List<Salary> queryResult = jdbcDemo.query();
        return appendLink(queryResult);
    }

    @RequestMapping(value = "/mybatis/salary", method = RequestMethod.GET)
    public @ResponseBody String queryByMyBatis() {
        List<Salary> queryResult = mybatisDemo.query();
        return appendLink(queryResult);
    }

    private String appendLink(List<Salary> queryResult) {
        StringBuilder result = new StringBuilder("query result : ");
        result.append("<br/>");
        result.append(queryResult);
        result.append("<br>");
        result.append("<hr>");
        result.append("[<a href=\"/tddl\"> Dev Home </a>]");
        result.append("&nbsp");
        result.append("[<a href=\"/\"> Home </a>]");
        return result.toString();
    }
}
