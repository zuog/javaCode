package com.alibaba.ylb.mtop;

import com.alibaba.boot.diamond.annotation.DiamondPropertySource;

import com.taobao.pandora.boot.PandoraBootstrap;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

/**
 * Pandora Boot应用的入口类
 * <p>
 * 其中导入sentinel-tracer.xml是加sentinel限流，详情见
 * http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-sentinel
 * <p>
 * 其中@DiamondPropertySource是导入来自Diamond Server的配置，详情见
 * http://gitlab.alibaba-inc.com/middleware-container/pandora-boot/wikis/spring-boot-diamond
 *
 * @author chengxu
 */
@SpringBootApplication(scanBasePackages = { "com.alibaba.ylb" })
@DiamondPropertySource(dataId = "com.taobao.middleware:test.properties")
@ImportResource({ "classpath*:sentinel-tracer.xml" })
public class Application {

    public static void main(String[] args) {
        PandoraBootstrap.run(args);
        SpringApplication.run(Application.class, args);
        PandoraBootstrap.markStartupAndWait();
    }
}
