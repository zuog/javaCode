package com.alibaba.ylb.mtop.uic;

import com.alibaba.ylb.mtop.TestApplication;
import com.alibaba.ylb.mtop.uic.UicQueryDemo.UserInfo;

import com.taobao.pandora.boot.test.junit4.DelegateTo;
import com.taobao.pandora.boot.test.junit4.PandoraBootRunner;
import junit.framework.TestCase;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 测试UIC的用户信息查询
 * 
 * @author chengxu
 */
@RunWith(PandoraBootRunner.class)
@DelegateTo(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { TestApplication.class })
public class UicTest {

    @Autowired
    private UicQueryDemo uicQueryDemo;

    // @Test
    public void testQuery() {
        String nickName = "pandora boot";
        long userId = uicQueryDemo.queryUserIdByNick(nickName);
        UserInfo userInfo = uicQueryDemo.queryUserByUserId(userId);
        TestCase.assertEquals(nickName, userInfo.getNick());
    }
}
