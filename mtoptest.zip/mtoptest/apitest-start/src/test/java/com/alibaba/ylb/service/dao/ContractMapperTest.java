/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;
import com.alibaba.ylb.mtop.tddl.mybatis.ContractMapper;
import com.alibaba.ylb.service.api.enums.ContractAuthorizationFileStatusEnum;
import com.alibaba.ylb.service.api.enums.ContractCommissionTypeEnum;
import com.alibaba.ylb.service.api.enums.ContractInvoiceStatusEnum;
import com.alibaba.ylb.service.api.enums.ContractPayDelegationFileStatusEnum;
import com.alibaba.ylb.service.api.enums.ContractPayStatusEnum;
import com.alibaba.ylb.service.api.enums.ContractStatusEnum;

import com.alibabapictures.sqbservice.module.ContractDO;
import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 类ContractMapperTest.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月11日 下午2:38:54
 */
// @RunWith(PandoraBootRunner.class)
// @DelegateTo(SpringJUnit4ClassRunner.class)
// @SpringBootTest(classes = { TestApplication.class })
@Ignore
public class ContractMapperTest extends MtopTestBase {

    @Autowired
    private ContractMapper contractMapper;
    


    // @Test
    public void test_insertContract() {

        // ApplicationContext ac = new ClassPathXmlApplicationContext("classpath*:applicationContext.xml");
        // contractMapper = (ContractMapper) ac.getBean("contractMapper");

        ContractDO contractDO = new ContractDO();
        contractDO.setRemark("备注");
        contractDO.setOverfulfilRatio(600);
        contractDO.setOtherChannel("其他渠道");
        contractDO.setMinimumShareAmount(1000000L);
        contractDO.setMinimumSaleAmount(100000000L);
        contractDO.setMinimumRatio(100);
        contractDO.setMerchantId(123L);
        contractDO.setGmtClearance(new Date());
        contractDO.setGmtAuthorizationStart(new Date());
        contractDO.setGmtAuthorizationEnd(new Date());
        contractDO.setCreator("000000");
        contractDO.setStatus(ContractStatusEnum.UNSIGNED);
        contractDO.setPayStatus(ContractPayStatusEnum.UNPAID);
        contractDO.setIpId(1234L);

        contractDO.setAuthorizationFileStatus(ContractAuthorizationFileStatusEnum.UNSEND);
        contractDO.setInvoiceStatus(ContractInvoiceStatusEnum.UNSEND);
        contractDO.setCommissionType(ContractCommissionTypeEnum.ORDINARY_COMMISSION);
        contractDO.setPayDelegationFileStatus(ContractPayDelegationFileStatusEnum.UNSUBMIT);

        contractMapper.insertContract(contractDO);
    }

    // @Test
    public void test_selectByContractId() {
        ContractDO contractDO = new ContractDO();
        Long id = 12L;
        contractDO = contractMapper.selectByContractId(id);
        p(contractDO);
    }

    @Test
    public void testListWelfares_app() {

        // 被测Mtop接口
        String apiName = "com.de.ylb.app.welfare.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pageNo", 1);
        map.put("pageSize", 10);
        map.put("appVersion", "20");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("welfareItemVO"));
    }
}