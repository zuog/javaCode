/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.mtop;

/**
 * 类Constant.java的实现描述
 * 
 * @author lingce 2017年9月4日 下午3:51:41
 */
public class Constant {

    public static String alipayId            = "2088102122981077"; // bc_03/111111
    public static String alipayId_xiangling6 = "2088102011918821"; // xiangling6/taobao1234
    public static String alipayId_xiangling7 = "2088102011918852"; // xiangling7/taobao1234/taobao1234

    public static String projectId           = "23842";
    public static Long   contractId          = 95L;
    public static String token               = "cb95fe5f-1cb7-40f9-995a-64ab67e9f30c";
    public static String ipID                = "90";
    public static String merchantToken       = "2de5ca99-2dab-49a7-8256-75f6de9d166e";

}
