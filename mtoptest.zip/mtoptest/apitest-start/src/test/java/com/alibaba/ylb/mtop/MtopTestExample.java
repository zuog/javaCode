/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.mtop;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.google.gson.JsonObject;
import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import com.taobao.mtop4.unit.tools.MtopApi;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 类MtopTestExample.java的实现描述
 * 
 * @author lingce 2017年8月29日 下午6:23:57
 */
public class MtopTestExample extends MtopTestBase {

    @Test
    public void testExample() {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.app.receivewelfare.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pageNo", 1);
        map.put("pageSize", 5);
        map.put("appVersion", "1");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("itemList"));
    }

    //@Test
    public void testGetUserInfo() throws Exception {

        // 被测Mtop接口
        String apiName = "com.taobao.taotv.ylb.mtop.YlbUserService.getUserInfo";

        Logger logger = LoggerFactory.getLogger(MtopTestExample.class);
        logger.info(apiName, this.getClass().getMethods().toString(), "");

        // 环境配置
        mtopApi = MtopApi.envDaily().api4().api(apiName);
        // 1.0是接口的版本 必填
        mtopApi = mtopApi.v("1.0");
        // 如果需要登录，使用如下方法，第一个参数是用户名，第二个参数是密码
        mtopApi = mtopApi.login("xiangling7", "taobao1234");
        long times;
        long beginTime = System.currentTimeMillis();
        Thread.sleep(1000);
        result = mtopApi.send();
        long endTime = System.currentTimeMillis();
        times = endTime - beginTime;

        System.out.println("times:" + times);
        p(result);
        Assert.assertTrue(result.isSuccess());

        JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        System.out.println("jsonObject" + jsonObject);
        String ret = jsonObject.get("ret").getAsString();
        Assert.assertEquals("SUCCESS::调用成功", ret);
        Assert.assertTrue(result.getResponseInfo().contains("true"));
    }

    //public static void main(String[] args) {
    //    int number = 10;
    //    int number1 = 10;
    //    //原始数二进制
    //    printInfo(number);
    //    number = number << 2;
    //    //左移一位
    //    printInfo(number);
    //    System.out.println("----"+number);
    //    number1 = number1 >> 2;
    //    //右移一位
    //    printInfo(number1);
    //    System.out.println("----"+number1);}

    //public static void main(String[] args) {
    //    int m = 500;
    //    Integer obj = new Integer(m);  // 手动装箱
    //    System.out.println("obj = "+obj);
    //    int n = obj.intValue();  // 手动拆箱
    //    System.out.println("n = " + n);
    //
    //    Integer obj1 = new Integer(500);
    //    System.out.println("obj 等价于 obj1？" + obj.equals(obj1));
    //}

    public static void main(String args[]) {
        int a=0, b=0, c=0;
        Random r = new Random();

        for(int i=0; i<3; i++) {
            try {
                b = r.nextInt();
                System.out.println("b=" + b);
                c = r.nextInt();
                System.out.println("c=" + c);
                System.out.println("b/c= "+b/c);
                a = 12345 / (b/c);
            } catch (ArithmeticException e) {
                System.out.println("Division by zero."+ e);
                a = 0; // set a to zero and continue
            }
            System.out.println("a: " + a);
        }
    }

    /**
     * 输出一个int的二进制数
     * @param num
     */
    private static void printInfo(int num){
        System.out.println(Integer.toBinaryString(num));
    }
}
