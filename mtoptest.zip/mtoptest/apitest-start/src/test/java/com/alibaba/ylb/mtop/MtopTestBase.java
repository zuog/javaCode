/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.mtop;

import java.util.Collection;
import java.util.Map;

import com.alibaba.fastjson.JSON;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import com.taobao.mtop4.unit.tools.MtopApi;
import org.junit.Assert;

/**
 * 类MtopTestBase.java的实现描述：mtop测试基类
 * 
 * @author lingce 2017年8月29日 下午6:17:35
 */
// @RunWith(PandoraBootRunner.class)
public class MtopTestBase {

    protected static JsonParser parser = new JsonParser();

    protected MtopApi         mtopApi;
    protected MtopApiResponse result = null;

    /**
     * 构造MTOP api
     * 
     * @param apiName
     */
    public void setUpMtop(String apiName) {
        // 根据环境设置请求函数
        try {
            mtopApi = MtopApi.envDaily().api4();
        } catch (NullPointerException e) {
        }
        // 设置接口和版本参数
        mtopApi = mtopApi.api(apiName).v("1.0");
        // if need 登录
        login();
    }

    public void login() {
        mtopApi = mtopApi.login("xiangling7", "taobao1234");
    }

    public void sendRequest() {
        // 向服务端发放请求，返回值是服务器端发放回来的结果；
        result = mtopApi.send();
    }

    public MtopApiResponse apiTest(String apiName, Map<String, Object> parmMap, boolean needLogin) {
        MtopApiResponse result = null;
        // 环境配置
        mtopApi = MtopApi.envDaily().api4().api(apiName).v("1.0");

        // 如果需要登录，使用如下方法，第一个参数是用户名，第二个参数是密码
        if (needLogin) {
            login();
        }

        // setUpMtop(apiName);

        for (String str : parmMap.keySet()) {

            // mtop请求参数
            mtopApi.addDataItem(str, parmMap.get(str));

        }
        long times;
        long beginTime = System.currentTimeMillis();
        // 向服务端发放请求，返回值是服务器端发放回来的结果；
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        result = mtopApi.send();
        long endTime = System.currentTimeMillis();
        times = endTime - beginTime;

        System.out.println("times:" + times);
        JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        System.out.println("jsonObject" + jsonObject);
        String ret = jsonObject.get("ret").getAsString();
        Assert.assertEquals("SUCCESS::调用成功", ret);
        p(ret);

        return result;
    }

    public MtopApiResponse apiTest1(String apiName, Map<String, Object> parmMap, boolean needLogin) {
        MtopApiResponse result = null;
        // 环境配置
        mtopApi = MtopApi.envDaily().api4().api(apiName).v("1.0");

        // 如果需要登录，使用如下方法，第一个参数是用户名，第二个参数是密码
        if (needLogin) {
            login();
        }

        // setUpMtop(apiName);

        for (String str : parmMap.keySet()) {

            // mtop请求参数
            mtopApi.addDataItem(str, parmMap.get(str));

        }
        long times;
        long beginTime = System.currentTimeMillis();
        // 向服务端发放请求，返回值是服务器端发放回来的结果；
        result = mtopApi.send();
        long endTime = System.currentTimeMillis();
        times = endTime - beginTime;

        System.out.println("times:" + times);
        JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        System.out.println("jsonObject" + jsonObject);
        String ret = jsonObject.get("ret").getAsString();
        p(ret);
        return result;
    }

    public MtopApiResponse apiTestNeedRetry(String apiName, Map<String, Object> parmMap, boolean needLogin) throws Exception {
        MtopApiResponse result = null;
        // 环境配置
       try{
           mtopApi = MtopApi.envDaily().api4().api(apiName).v("1.0");
       

        // 如果需要登录，使用如下方法，第一个参数是用户名，第二个参数是密码
        if (needLogin) {
            login();
        }

        // setUpMtop(apiName);

        for (String str : parmMap.keySet()) {

            // mtop请求参数
            mtopApi.addDataItem(str, parmMap.get(str));

        }
        long times;
        long beginTime = System.currentTimeMillis();
        // 向服务端发放请求，返回值是服务器端发放回来的结果；
            Thread.sleep(500);
        result = mtopApi.send();
        long endTime = System.currentTimeMillis();
        times = endTime - beginTime;

        System.out.println("times:" + times);
        JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        System.out.println("jsonObject" + jsonObject);
        String ret = jsonObject.get("ret").getAsString();
        p(ret);
        } catch (Exception ex) {
            System.out.print(ex);
        }
        return result;
    }

    // 授权宝mtop接口测试调用api
    public MtopApiResponse sqbApiTest(String apiName, Map<String, Object> parmMap, boolean needLogin) {
        MtopApiResponse result = null;
        // 环境配置
        mtopApi = MtopApi.envDaily().api4().api(apiName).v("1.0");

        // 如果需要登录，使用如下方法，第一个参数是用户名，第二个参数是密码
        if (needLogin) {
            login();
        }

        // setUpMtop(apiName);

        for (String str : parmMap.keySet()) {

            // mtop请求参数
            mtopApi.addDataItem(str, parmMap.get(str));
        }
        mtopApi.addDataItem("token", Constant.token);
        long times;
        long beginTime = System.currentTimeMillis();
        // 向服务端发放请求，返回值是服务器端发放回来的结果；
        result = mtopApi.send();
        long endTime = System.currentTimeMillis();
        times = endTime - beginTime;

        System.out.println("times:" + times);
        JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        System.out.println("jsonObject" + jsonObject);
        String ret = jsonObject.get("ret").getAsString();
        Assert.assertEquals("SUCCESS::调用成功", ret);
        p(ret);
        return result;
    }

    // 授权宝mtop接口测试调用api
    public MtopApiResponse sqbMerchantApiTest(String apiName, Map<String, Object> parmMap, boolean needLogin) {
        MtopApiResponse result = null;
        // 环境配置
        mtopApi = MtopApi.envDaily().api4().api(apiName).v("1.0");

        // 如果需要登录，使用如下方法，第一个参数是用户名，第二个参数是密码
        if (needLogin) {
            login();
        }

        // setUpMtop(apiName);

        for (String str : parmMap.keySet()) {

            // mtop请求参数
            mtopApi.addDataItem(str, parmMap.get(str));
        }
        mtopApi.addDataItem("token", Constant.merchantToken);
        long times;
        long beginTime = System.currentTimeMillis();
        // 向服务端发放请求，返回值是服务器端发放回来的结果；
        result = mtopApi.send();
        long endTime = System.currentTimeMillis();
        times = endTime - beginTime;

        System.out.println("times:" + times);
        JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        System.out.println("jsonObject" + jsonObject);
        String ret = jsonObject.get("ret").getAsString();
        Assert.assertEquals("SUCCESS::调用成功", ret);
        p(ret);
        return result;
    }

    private static final String SYS_OUT_PREFIX = "#################";

    public static void p(Object o) {
        System.out.println(SYS_OUT_PREFIX + (o == null ? "<null>" : JSON.toJSONString(o)));
    }

    public static void plist(Collection<?> list) {
        String result = "";
        if (list == null) {
            result = "<null>";
        } else if (list.size() == 0) {
            result = "<empty>";
        } else {
            result = JSON.toJSONString(list);
        }
        System.out.println(SYS_OUT_PREFIX + "!!size:" + ((null == list) ? 0 : list.size()) + "!!\ncontent:" + result);
    }
}
