package com.alibaba.ylb.java.test;

/**
 * 类Producer的实现描述：
 *
 * @author lingce 17/11/11 上午11:13
 */
class Producer implements Runnable {
    Q q;

    Producer(Q q) {
        this.q = q;
        new Thread(this, "Producer").start();
    }

    public void run() {
        int i = 0;
        while (true) {
            q.put(i++);
        }
    }
}
