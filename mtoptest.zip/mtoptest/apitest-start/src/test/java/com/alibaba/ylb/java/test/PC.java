package com.alibaba.ylb.java.test;

/**
 * 类PC的实现描述：
 *
 * @author lingce 17/11/11 上午11:30
 */
public class PC {
    public static void main(String[] args){
        Q q = new Q();
        new Producer(q);
        new Consumer(q);
        System.out.print("Press Control-C to stop");
    }
}
