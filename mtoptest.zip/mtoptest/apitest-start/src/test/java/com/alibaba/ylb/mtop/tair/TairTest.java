package com.alibaba.ylb.mtop.tair;

import com.alibaba.ylb.mtop.TestApplication;

import com.taobao.pandora.boot.test.junit4.DelegateTo;
import com.taobao.pandora.boot.test.junit4.PandoraBootRunner;
import junit.framework.TestCase;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 测试Tair读写信息
 * 
 * @author chengxu
 */
@RunWith(PandoraBootRunner.class)
@DelegateTo(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { TestApplication.class })
public class TairTest {

    @Autowired
    private TairProperties tairProperties;

    // @Test
    public void testTair() {
        try {
            TestCase.assertTrue(tairProperties.put("name", "core engine"));
            TestCase.assertEquals("core engine", tairProperties.get("name"));
            TestCase.assertTrue(tairProperties.delete("name"));
        } catch (Exception e) {
            TestCase.fail(e.getMessage());
        }
    }
}
