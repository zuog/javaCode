/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.mtop;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

/**
 * 类AllTests.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年8月30日 下午6:00:58
 */
@RunWith(Suite.class)
@SuiteClasses({ MtopTestExample.class })
public class AllTest {

}
