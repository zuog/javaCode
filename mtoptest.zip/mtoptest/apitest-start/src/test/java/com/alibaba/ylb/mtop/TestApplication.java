package com.alibaba.ylb.mtop;

import com.alibaba.boot.diamond.annotation.DiamondPropertySource;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

/**
 * 单元测试的Spring Boot配置类
 * @author chengxu
 */
@SpringBootApplication(scanBasePackages = { "com.alibaba.ylb" })
@PropertySource(value = { "classpath:test.properties" })
@DiamondPropertySource(dataId = "com.taobao.middleware:test.properties")
@ImportResource({ "classpath*:applicationContext.xml" })
public class TestApplication {

}
