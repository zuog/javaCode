/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alibaba.ylb.service.dao;

import com.alibaba.ylb.mtop.MtopTestBase;
import com.alibaba.ylb.mtop.TestApplication;
import com.alibaba.ylb.mtop.tddl.mybatis.MerchantMapper;

import com.alibabapictures.sqbservice.module.MerchantDO;
import com.taobao.pandora.boot.test.junit4.DelegateTo;
import com.taobao.pandora.boot.test.junit4.PandoraBootRunner;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * 类MerchantMapperTest.java的实现描述
 * 
 * @author lingce 2017年9月13日 下午7:11:48
 */
@RunWith(PandoraBootRunner.class)
@DelegateTo(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = { TestApplication.class })
@Ignore
public class MerchantMapperTest extends MtopTestBase {

    @Autowired
    public MerchantMapper merchantMapper;

    // @Test
    public void test_getById() {
        MerchantDO merchantDO = new MerchantDO();
        long id = 1;
        merchantDO = merchantMapper.getById(id);
        p(merchantDO);
        Assert.assertEquals("周大福", merchantDO.getName());
    }

}
