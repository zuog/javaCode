package com.alibaba.ylb.java.test;

/**
 * 类Consumer的实现描述：
 *
 * @author lingce 17/11/11 上午11:28
 */
public class Consumer implements Runnable {
    Q q;
    Consumer(Q q){
        this.q = q;
        new Thread(this, "Consumer").start();
    }
    public void run(){
        while (true){
            q.get();
        }
    }
}
