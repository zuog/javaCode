/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alipictures.sqbservice.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.Constant;
import com.alibaba.ylb.mtop.MtopTestBase;
import com.alibaba.ylb.mtop.tddl.mybatis.ContractMapper;
import com.alibaba.ylb.mtop.tddl.mybatis.MerchantMapper;

import com.alibabapictures.sqbservice.api.request.admin.CreateContractRequest;
import com.alibabapictures.sqbservice.service.MerchantService;
import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 类ContractAdminApiTest.java的实现描述
 * 
 * @author lingce 2017年9月13日 上午10:05:13
 */
// @RunWith(PandoraBootRunner.class)
// @DelegateTo(SpringJUnit4ClassRunner.class)
// @SpringBootTest(classes = { TestApplication.class })
@Ignore
public class ContractAdminApiTest extends MtopTestBase {

    @Autowired
    private ContractMapper  contractMapper;

    @Autowired
    private MerchantService merchantService;

    @Autowired
    public MerchantMapper   merchantMapper;

    @Test
    public void test_contractDetail_getNumber() {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.sqb.admin.contract.detail";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("contractId", Constant.contractId);
        // map.put("token", Constant.token);
        MtopApiResponse result = sqbApiTest(apiName, map, false);

        // ContractDO contractDO = new ContractDO();
        // Long id = Constant.contractId;
        // contractDO = contractMapper.selectByContractId(id);
        // p("contractDO.getNumber:" + contractDO.getNumber());
        //
        // JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        // String contractNumber = ((JsonObject) ((JsonObject)
        // jsonObject.get("data")).get("value")).get("contractNumber").getAsString();
        //
        // System.out.println("contractNumber:" + contractNumber);
        // Assert.assertTrue(contractNumber.equals(contractDO.getNumber()));
        Assert.assertTrue(result.getResponseInfo().contains("merchantLoginName"));

    }

    @Test
    public void test_contractDetail_getMerchantPhone() {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.sqb.admin.contract.detail";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("contractId", Constant.contractId);
        MtopApiResponse result = sqbApiTest(apiName, map, false);

        // ContractDO contractDO = new ContractDO();
        // Long id = Constant.contractId;
        // contractDO = contractMapper.selectByContractId(id);
        // if (contractDO != null) {
        //
        // }
        // p("contractDO.getNumber:" + contractDO.getNumber());
        //
        // MerchantDO merchantDO = merchantService.getById(contractDO.getMerchantId());
        //
        // JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        // String merchantPhone = ((JsonObject) ((JsonObject)
        // jsonObject.get("data")).get("value")).get("merchantPhone").getAsString();
        // System.out.println("merchantPhone:" + merchantPhone);
        // Assert.assertTrue(result.getResponseInfo().contains("15201123485"));
        // // Assert.assertTrue(merchantPhone.equals(merchantDO.getPhone()));
        Assert.assertTrue(result.getResponseInfo().contains("merchantLoginName"));
    }

    // @Test TODO 系统异常？
    public void test_createContract() {

        CreateContractRequest request = new CreateContractRequest();
        request.setToken(Constant.token);
        request.setMerchantLoginName("TEST0001");
        request.setMerchantPhone("13012345678");
        // request.setLeafCategoryIdList("[123,4456]");
        request.setLeafCategoryIdList("[\"12\",\"8\",\"9\"]");
        request.setMinimumSaleAmount("720000001");
        request.setMinimumShareAmount("600000001");
        request.setCommissionType("1");
        request.setIpId(Constant.ipID);
        request.setLadderCommissionList("[{\"amount\": 10000,\"ratio\": 12.34},{\"amount\": 20000,\"ratio\": 10.34}]");
        request.setMinimumRatio("6.44");
        request.setOverfulfilRatio("1.00");
        request.setAuthorizationStartTime("2017-09-22");
        request.setAuthorizationEndTime("2019-09-29");
        request.setClearanceEndTime("2018-11-22");
        request.setOtherChannel("其他渠道");
        request.setRemark("备注信息");
        request.setChannelIdList("[12,23,34]");


        // 被测Mtop接口
        String apiName = "mtop.alipictures.sqb.admin.contract.create";
        Map<String, Object> map = new HashMap<String, Object>();
        // map.put("token", request.getToken());
        map.put("merchantLoginName", request.getMerchantLoginName());
        map.put("merchantPhone", request.getMerchantPhone());
        map.put("leafCategoryIdList", request.getLeafCategoryIdList());
        map.put("minimumShareAmount", request.getMinimumShareAmount());
        map.put("minimumSaleAmount", request.getMinimumSaleAmount());
        map.put("commissionType", request.getCommissionType());
        map.put("ipId", request.getIpId());
        map.put("ladderCommissionLis", request.getLadderCommissionList());
        map.put("minimumRatio", request.getMinimumRatio());
        map.put("overfulfilRatio", request.getOverfulfilRatio());
        map.put("authorizationStartTime", request.getAuthorizationStartTime());
        map.put("authorizationEndTime", request.getAuthorizationEndTime());
        map.put("clearanceEndTime", request.getClearanceEndTime());
        map.put("otherChannel", request.getOtherChannel());
        map.put("remark", request.getRemark());
        map.put("channelIdList", request.getChannelIdList());

        MtopApiResponse result = sqbApiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("value"));

    }

    @Test
    public void test_listContract() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.sqb.admin.contract.list";
        Map<String, Object> map = new HashMap<String, Object>();
        MtopApiResponse result = sqbApiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("merchantLoginName"));
    }

}
