/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alipictures.sqbservice.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Ignore;

/**
 * 类MerchantApiTest.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月15日 下午7:53:56
 */
@Ignore
public class MerchantApiTest extends MtopTestBase {

    // @Test TODO 接口异常需修复
    public void test_adminMerchantGet() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.sqb.merchant.merchant.get";
        Map<String, Object> map = new HashMap<String, Object>();
        MtopApiResponse result = sqbMerchantApiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("contactInfo"));
    }

}
