/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alipictures.sqbservice.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

/**
 * 类ConsulationWebsiteApiTest.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月15日 下午7:19:13
 */
@Ignore
public class ConsulationWebsiteApiTest extends MtopTestBase {

    @Test
    public void test_save() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.sqb.website.consulation.save";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("merchantName", "merchantName_Test");
        map.put("contactPerson", "contactPerson_Test");
        map.put("contactPhone", "contactPhone_Test");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("value"));
    }

}
