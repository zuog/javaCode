/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.alipictures.sqbservice.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.Constant;
import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

/**
 * 类AdminIpApiTest.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月16日 下午8:04:30
 */
@Ignore
public class AdminIpApiTest extends MtopTestBase {

    @Test
    public void test_listIp() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.sqb.admin.ip.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pageIndex", 1);
        map.put("pageSize", 10);
        map.put("token", Constant.token);
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("contactPerson"));
    }

    @Test
    public void test_listAllIpNames() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.sqb.admin.ip.name.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("token", Constant.token);
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("name"));
    }

    @Test
    public void test_ipView() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.sqb.admin.ip.view";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("id", Constant.ipID);
        map.put("token", Constant.token);
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("name"));
    }
}
