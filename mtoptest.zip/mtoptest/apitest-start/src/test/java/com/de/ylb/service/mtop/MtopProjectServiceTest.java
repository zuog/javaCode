/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.de.ylb.service.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Test;

/**
 * 类MtopProjectServiceTest.java的实现描述
 * 
 * @author lingce 2017年8月31日 下午8:11:59
 */
public class MtopProjectServiceTest extends MtopTestBase {

    /**
     * API功能描述: 根据用户查询项目列表
     * 
     * @throws Exception
     */
    @Test
    public void testListProjectsByUser_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.gw.project.my";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("type", 1);
        map.put("pageNo", 1);
        map.put("pageSize", 10);
        map.put("appVersion", "20");
        map.put("alipayId", "2088102122981077");
        for (int i = 0; i <= 3; i++) {
            Thread.sleep(1000);
            MtopApiResponse result = apiTestNeedRetry(apiName, map, false);
            if (result.getResponseInfo().contains("dataList")) {
                Assert.assertTrue(result.getResponseInfo().contains("dataList"));
                return;
            }
        }
    }

    //@Test
    public void testListProjectsByUser_app() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.app.project.my";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("type", 1);
        map.put("pageNo", 1);
        map.put("pageSize", 10);
        map.put("appVersion", "20");
        for (int i = 0; i <= 3; i++) {
            Thread.sleep(1000);
            MtopApiResponse result = apiTestNeedRetry(apiName, map, true);
            if (result.getResponseInfo().contains("dataList")) {
                Assert.assertTrue(result.getResponseInfo().contains("dataList"));
                return;
            }
        }
    }

    @Test
    public void testListTrustProjects_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.gw.trust.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pageNo", 1);
        map.put("pageSize", 10);
        map.put("appVersion", "20");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("projectItemVO"));
    }

    @Test
    public void testListTrustProjects_app() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.app.trust.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pageNo", 1);
        map.put("pageSize", 10);
        map.put("appVersion", "20");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("projectItemVO"));
    }

    @Test
    public void testListProjects_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.gw.project.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("projectType", 1);
        map.put("pageNo", 1);
        map.put("pageSize", 10);
        map.put("appVersion", "20");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("projectItemVO"));
    }

    @Test
    public void testListProjects_app() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.app.project.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("projectType", 1);
        map.put("pageNo", 1);
        map.put("pageSize", 10);
        map.put("appVersion", "20");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("projectItemVO"));
    }
}
