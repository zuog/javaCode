/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.de.ylb.service.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Test;

/**
 * 类MtopCommentServiceTest.java的实现描述
 * 
 * @author lingce 2017年9月1日 下午2:17:57
 */
public class MtopCommentServiceTest extends MtopTestBase {

    @Test
    public void testListComments_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.gw.comment.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("topicId", 1499);
        map.put("appVersion", "1.0");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("commentList"));
    }

    @Test
    public void testListComments_app() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.app.comment.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("topicId", 1499);
        map.put("appVersion", "1.0");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("commentList"));
    }
}
