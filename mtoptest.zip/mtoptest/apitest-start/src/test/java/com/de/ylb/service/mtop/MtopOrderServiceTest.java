/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.de.ylb.service.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.security.util.StringUtils;
import com.alibaba.ylb.mtop.Constant;
import com.alibaba.ylb.mtop.MtopTestBase;

import com.google.gson.JsonObject;
import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Test;

/**
 * 类MtopOrderServiceTest.java的实现描述：TODO 类实现描述
 * 
 * @author lingce 2017年9月4日 下午3:35:25
 */
public class MtopOrderServiceTest extends MtopTestBase {

    /**
     * API功能描述: 信托项目订单确认页面
     * 
     * @throws Exception
     */

    // @Test
    // @Before
    public void testCloseOrder() throws Exception {

        String apiName = "mtop.alipictures.ylb.app.trustitem.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("projectId", Constant.projectId);
        map.put("appVersion", "20");
        map.put("projectType", 1);
        MtopApiResponse result = apiTest1(apiName, map, true);

        JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        String wait4PayOrderId = ((JsonObject) ((JsonObject) ((JsonObject) jsonObject.get("data")).get("data")).get("trustItemList")).get("wait4PayOrderId").getAsString();
        System.out.println("wait4PayOrderId:" + wait4PayOrderId);

        Thread.sleep(1000);

        // 被测Mtop接口
        if (!wait4PayOrderId.equals("0")) {
            MtopApiResponse result1 = null;
            for (int i = 1; i <= 10; i++) {
                Thread.sleep(1000);
                String apiName1 = "mtop.ylb.app.trust.order.close";
                Map<String, Object> map1 = new HashMap<String, Object>();
                map1.put("orderId", wait4PayOrderId);
                result1 = apiTest1(apiName1, map1, true);
                if (!result1.getResponseInfo().contains("successful")) {
                    Thread.sleep(10000);
                } else {
                    Assert.assertTrue(result1.getResponseInfo().contains("successful"));
                    return;
                }
            }
            Assert.assertTrue(result1.getResponseInfo().contains("successful"));
        }
    }

    //@Test
    public void testConfirmTrustOrder_app() throws Exception {


        // 被测Mtop接口
        String apiName2 = "mtop.ylb.app.trust.order.confirm";
        Map<String, Object> map2 = new HashMap<String, Object>();
        map2.put("trustProjectId", "23842");
        map2.put("appVersion", "1.0");
        map2.put("itemId", 18765);
        map2.put("buyAmount", 1);
        Thread.sleep(500);
        MtopApiResponse result2 = apiTest(apiName2, map2, true);
        if (result2 != null && StringUtils.isNotBlank(result2.getResponseInfo())) {
            Assert.assertTrue(result2.getResponseInfo().contains("availableQuantity"));
        }
    }

    @Test
    public void testConfirmTrustOrder_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.ylb.gw.trust.order.confirm";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("trustProjectId", "23842");
        map.put("appVersion", "1.0");
        map.put("itemId", 18765);
        map.put("buyAmount", 1);
        map.put("alipayId", Constant.alipayId_xiangling7);
        Thread.sleep(500);
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("availableQuantity"));
    }

    // @Test
    public void testCreateDreamOrder_gw() throws Exception {

        // 获取token
        String apiName = "mtop.ylb.gw.trust.order.confirm";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("trustProjectId", "23842");
        map.put("appVersion", "1.0");
        map.put("itemId", 18765);
        map.put("buyAmount", 1);
        map.put("alipayId", Constant.alipayId);
        MtopApiResponse result = apiTest(apiName, map, false);


        JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        String buyToken = ((JsonObject) ((JsonObject) jsonObject.get("data")).get("data")).get("buyToken").getAsString();
        System.out.println("buyToken:" + buyToken);

        Thread.sleep(2000);

        // 创建订单
        String apiName1 = "mtop.ylb.gw.dream.order.create";
        Map<String, Object> map1 = new HashMap<String, Object>();
        map1.put("dreamProjectId", Constant.projectId);
        map1.put("appVersion", "1.0");
        map1.put("dreamItemId", 18765);
        map1.put("buyAmount", 1);
        map1.put("alipayId", Constant.alipayId_xiangling7);

        map1.put("addressId", 0);
        map1.put("buyToken", buyToken);
        map1.put("orderTrackId", "206200@taobao_android_3.0");
        map1.put("signImgUrl", "http://www.taobao.com");
        map1.put("userRemark", "userRemark");
        MtopApiResponse result1 = apiTest(apiName1, map1, false);
        Assert.assertTrue(result1.getResponseInfo().contains("dreamOrderId"));


    }

    @Test
    public void testTrustitemList() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.app.trustitem.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("projectId", Constant.projectId);
        map.put("appVersion", "20");
        map.put("projectType", 1);
        Thread.sleep(500);
        MtopApiResponse result = apiTest(apiName, map, true);

        JsonObject jsonObject = parser.parse(result.getResponse()).getAsJsonObject();
        String wait4PayOrderId = ((JsonObject) ((JsonObject) ((JsonObject) jsonObject.get("data")).get("data")).get("trustItemList")).get("wait4PayOrderId").getAsString();
        System.out.println("wait4PayOrderId:" + wait4PayOrderId);
        Assert.assertTrue(result.getResponseInfo().contains("wait4PayOrderId"));
    }

    public static void main(String[] args) {
        String a = "{\"api\":\"mtop.ylb.app.trust.order.confirm\",\"data\":{\"code\":\"200\",\"data\":{\"buyAmount\":\"0\",\"buyToken\":\"9017cfb80e00824883c6487c070ba012\",\"userCanBuyQuantity\":\"0\"},\"message\":\"successful\",\"traceId\":\"2a7dfc21-cdaf-475f-8342-9b3eff08438c\",\"ts\":\"1504512027064\"},\"ret\":[\"SUCCESS::调用成功\"],\"v\":\"1.0\"}";
        JsonObject jsonObject = parser.parse(a).getAsJsonObject();
        System.out.println("jsonObject" + jsonObject);
        String ret = ((JsonObject) ((JsonObject) jsonObject.get("data")).get("data")).get("buyToken").getAsString();
        System.out.println("buyToken:" + ret);
        String investmentCycleText = "12个月";
        int investmentCycle = Integer.parseInt(investmentCycleText);
        System.out.println("investmentCycle:" + investmentCycle);
    }

}
