/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.de.ylb.service.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Test;

/**
 * 类MtopUserService4AlipayTest.java的实现描述
 * 
 * @author lingce 2017年8月31日 上午10:03:51
 */
public class MtopUserServiceTest extends MtopTestBase {

    @Test
    public void testGetUserData() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.gw.wealth.userdata";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("alipayId", "2088102122981077");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("totalMoney"));
    }

    @Test
    public void testGetRedDotRule() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.gw.reddot.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("alipayId", "2088102122981077");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("\"redDotMark\":\"true\""));

    }

    /**
     * API功能描述: 支付宝 查询用户信息
     */
    @Test
    public void testUserGet_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.gw.user.get";
        Map<String, Object> parmMap = new HashMap<String, Object>();
        parmMap.put("needBuyInfo", false);
        // bc_03
        parmMap.put("alipayId", "2088102122981077");
        parmMap.put("needDreamInfo", false);
        parmMap.put("needWelfareInfo", false);
        parmMap.put("needC2bProjectInfo", false);
        MtopApiResponse result = apiTest(apiName, parmMap, false);
        Assert.assertTrue(result.getResponseInfo().contains("totalProfitPriceFee"));

    }
    
    @Test
    public void testGetUserInfo() throws Exception {

        // 被测Mtop接口
        String apiName = "com.taobao.taotv.ylb.mtop.YlbUserService.getUserInfo";
        Map<String, Object> parmMap = new HashMap<String, Object>();
        MtopApiResponse result = apiTest(apiName, parmMap, true);
        Assert.assertTrue(result.getResponseInfo().contains("\"logined\":\"true\""));

    }

}
