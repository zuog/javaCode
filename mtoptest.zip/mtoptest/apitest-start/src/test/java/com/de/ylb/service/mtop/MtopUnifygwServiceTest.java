/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.de.ylb.service.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Test;

/**
 * 类MtopUnifygwServiceTest.java的实现描述
 * 
 * @author lingce 2017年9月1日 下午2:03:06
 */
public class MtopUnifygwServiceTest extends MtopTestBase {

    @Test
    public void testSyncdata_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.gw.syncdata";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("from", "unknown");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("needResetIds"));
    }

    @Test
    public void testHeartbeat_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.gw.heartbeat";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("from", "unknown");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("\"data\":\"i am fine!\""));
    }

}
