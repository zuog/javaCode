/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.de.ylb.service.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;
import com.alibaba.ylb.mtop.tddl.mybatis.ContractMapper;

import com.alibabapictures.sqbservice.module.ContractDO;
import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 类MtopWelfareServiceTest.java的实现描述
 * 
 * @author lingce 2017年8月31日 下午8:09:04
 */
// @RunWith(PandoraBootRunner.class)
// @DelegateTo(SpringJUnit4ClassRunner.class)
// @SpringBootTest(classes = { TestApplication.class })
public class MtopWelfareServiceTest extends MtopTestBase {

    @Autowired
    private ContractMapper contractMapper;

    /**
     * API功能描述: 根据查询项目列表
     */
    @Test
    public void testListWelfares_gw() {

        // 被测Mtop接口
        String apiName = "com.de.ylb.gw.welfare.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pageNo", 1);
        map.put("pageSize", 10);
        map.put("appVersion", "20");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("welfareItemVO"));
    }

    @Test
    public void testListWelfares_app() {

        // 被测Mtop接口
        String apiName = "com.de.ylb.app.welfare.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pageNo", 1);
        map.put("pageSize", 10);
        map.put("appVersion", "20");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("welfareItemVO"));
    }

    // @Test
    public void test_selectByContractId() {
        ContractDO contractDO = new ContractDO();
        Long id = 12L;
        contractDO = contractMapper.selectByContractId(id);
        p(contractDO);
    }

}
