/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.de.ylb.service.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Test;

/**
 * 类MtopTrustProjectService.java的实现描述
 * 
 * @author lingce 2017年9月1日 下午1:30:08
 */
public class MtopTrustProjectServiceTest extends MtopTestBase {

    @Test
    public void testGetTrustDetailById_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.gw.trust.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("appVersion", "1.0");
        map.put("turstProjectId", 23774);
        map.put("alipayId", "2088102122981077");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("trustDetailVO"));
    }

    @Test
    public void testGetTrustDetailById_app() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.app.trust.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("appVersion", "1.0");
        map.put("turstProjectId", 23774);
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("trustDetailVO"));
    }

    @Test
    public void testGetDetailLayer_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.gw.trustdetail.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("appVersion", "1.0");
        map.put("turstProjectId", 23774);
        map.put("layerType", 1);
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("data"));
    }

    @Test
    public void testGetDetailLayer_app() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.app.trustdetail.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("appVersion", "1.0");
        map.put("turstProjectId", 23774);
        map.put("layerType", 1);
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("data"));
    }

    /**
     * API功能描述: 根据tbUserId获取用户淘宝地址信息 
     * API名称: mtop.alipictures.ylb.app.addresses.get
     * 
     * @throws Exception
     */

    @Test
    public void testGetAdressByTbUserID_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.gw.addresses.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("alipayId", "2088102122981077");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("addressId"));
    }

    // @Test
    public void testGetAdressByTbUserID_app() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.app.addresses.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("appVersion", "1.0");
        MtopApiResponse result = apiTest(apiName, map, true);
        Assert.assertTrue(result.getResponseInfo().contains("successful"));
    }
    
    /**
     * API功能描述: 获取项目下的回报项列表 
     * API名称: mtop.alipictures.ylb.app.trustitem.list
     * 
     * @throws Exception
     */

    // @Test
    public void testGetTrustItemListById_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.gw.trustitem.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("projectId", "23774");
        map.put("appVersion", "20");
        map.put("alipayId", "2088102122981077");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("您已经达到个人购买的最大限额"));
    }

    // @Test
    public void testGetTrustItemListById_app() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.app.trustitem.list";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("projectId", "23774");
        map.put("appVersion", "20");
        map.put("projectType", 1);
        MtopApiResponse result = apiTest(apiName, map, true);
        Assert.assertTrue(result.getResponseInfo().contains("trustItemList"));
    }

}
