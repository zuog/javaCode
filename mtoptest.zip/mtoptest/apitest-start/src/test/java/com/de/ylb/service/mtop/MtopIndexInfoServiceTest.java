/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.de.ylb.service.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Test;

/**
 * 类MtopIndexInfoService4AlipayTest.java的实现描述
 * 
 * @author lingce 2017年8月31日 上午10:36:38
 */
public class MtopIndexInfoServiceTest extends MtopTestBase {

    @Test
    public void testGetAppIndexInfo_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.gw.index.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("pageNo", 1);
        map.put("pageSize", 5);
        map.put("appVersion", "1");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("projects"));
    }

    @Test
    public void testGetAppIndexInfo_app() throws Exception {

        // 被测Mtop接口
        String apiName = "com.de.ylb.app.index.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("appVersion", "20");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("projects"));
    }
}
