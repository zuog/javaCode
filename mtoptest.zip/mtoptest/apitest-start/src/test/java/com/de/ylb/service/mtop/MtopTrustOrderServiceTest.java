/*
 * Copyright 2017 Alibaba.com All right reserved. This software is the
 * confidential and proprietary information of Alibaba.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with Alibaba.com.
 */
package com.de.ylb.service.mtop;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.ylb.mtop.MtopTestBase;

import com.taobao.mtop4.unit.protocol.MtopApiResponse;
import org.junit.Assert;
import org.junit.Test;

/**
 * 类MtopTrustOrderServiceTest.java的实现描述：TODO 类实现描述 
 * @author lingce 2017年9月1日 下午6:00:26
 */
public class MtopTrustOrderServiceTest extends MtopTestBase {

    /**
     * API功能描述: 信托项目订单详情-gw
     * 
     * @throws Exception
     */
    @Test
    public void testGetTrustOrderDetailById_gw() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.gw.trustorder.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("orderId", "150354403817277");
        map.put("alipayId", "2088102122981077");
        MtopApiResponse result = apiTest(apiName, map, false);
        Assert.assertTrue(result.getResponseInfo().contains("boxOffice"));
        Assert.assertTrue(result.getResponseInfo().contains("orderDetail"));
        Assert.assertTrue(result.getResponseInfo().contains("rightsBox"));
    }

    // @Test
    public void testGetTrustOrderDetailById_app() throws Exception {

        // 被测Mtop接口
        String apiName = "mtop.alipictures.ylb.app.trustorder.get";
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("orderId", "150354403817277");
        MtopApiResponse result = apiTest(apiName, map, true);
        Assert.assertTrue(result.getResponseInfo().contains("boxOffice"));
        Assert.assertTrue(result.getResponseInfo().contains("orderDetail"));
        Assert.assertTrue(result.getResponseInfo().contains("rightsBox"));
    }

}
